$(document).on('submit', "#doc-profile-form,#doc-changepass-form,#qual-list-form,#qualSec,#doc-clinic-addr-form", function(evt){

/*$("#doc-profile-form,#doc-changepass-form,#qual-list-form,#qualSec").submit(function(evt){*/
	evt.preventDefault();
	var url=$(this).attr("action");
	var form = $(this);
	var postdata=$(this).serialize();
	$.post(url,postdata,function(out){
		var error=out.errors;
		$(".form-group").find(".text-danger").remove();
		if (out.result==0) {
			for(var i in error){
				$("#"+i).parents(".form-group").append("<span style='font-weight:bold;' class='text-danger'>"+error[i]+"</span>");
			}
		}
		if (out.result==1) {
			$("#alert-msg-docpro,#alert-msg-docpass").html(out.msg).removeClass("hidden").removeClass("alert-danger").addClass("alert-success");
		}
		if (out.result==-1) {
			$("#alert-msg-docpro,#alert-msg-docpass").html(out.msg).removeClass("hidden").addClass("alert-success");	
		}
		if (out.result==2) {
			$("#alert-msg-docq").removeClass("hidden").removeClass("alert-danger").addClass("alert-success").html(out.msg);
			var qual=out.qual;
			$.each(qual,function(k,v){
				$("#qual-list-tbl").append("<tr><form id='qualSec' class='qualSec' method='POST' action='"+siteUrl+"'><td><input type='hidden' class='qualVal' id='qualVal' name='qualVal' value='"+v+"'><p style='color:#337ab7;font-weight:bold;'>"+v+"</p></td><td><input type='submit' name='qualDel' id='qualDel' class='btn btn-danger' value='Delete'></td></form></tr>");
			});
			//$("#qual-list-tbl").append("<form id='qualSec' class='qualSec' method='POST' action='" + siteUrl + "front/doDeleteDocQual'><tr><td><input type='hidden' name='qualVal' class='qualVal' id='qualVal' value='"+qual+"'><p style='color:#337ab7;font-weight=bold;' class='qualValp'>"+qual+"</p></td><td><input type='submit' name='qualDel' id='qualDel' class='btn btn-danger' value='Delete'></td></tr></form>");
			
		}
		if (out.result==-2) {
			$("#alert-msg-docq").removeClass("hidden").html(out.msg);
		}
		if (out.result==3) {
			$(".qualValp").remove();
			//$(form).remove();
			//$(form).hide();
			//console.log(this);
			$("#alert-msg-docq").removeClass("hidden").html(out.msg);
		}
		if (out.result==4) {
			$("#alert-msg").html(out.msg).removeClass("hidden").removeClass("alert-danger").addClass("alert-success");
		}
		if (out.result==-4) {
			$("#alert-msg").html(out.msg).removeClass("hidden");
		}

	});
});
