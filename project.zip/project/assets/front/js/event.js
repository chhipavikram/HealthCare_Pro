$(function() {
  $('.state-list').selectize();
});
$(function(){
	$('.qual-list').selectize({
		maxItems:100
	});
});
$(function(){
	$('.speciality-list').selectize();
});
$(function(){
	$('.docSpeciality').selectize();
});