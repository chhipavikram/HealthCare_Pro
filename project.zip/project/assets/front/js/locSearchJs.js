$(document).on("change","#statelist",function(){
//$("#statelist,#state-name").change(function(){
	var state=$(this).val();
	$("#citylist").empty();
	$.post("front/doGetCityList",{state_id:state},function(data){
		$.each(data.city,function(k,v){
			$("#citylist").append("<option value='"+v.name+"'>"+v.name+"</option>");
		});
		/*$(".city-list").removeClass("form-control");
		$(".city-list").selectize();*/
	});
});