$(document).on("submit","#login-check-form,#appointment-final-form,#msg-check-form",function(evt){
	evt.preventDefault();
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(out){
		if (out.result==1) {
			$("#appoint-modal").modal("show");
		}
		if (out.result==-1) {
			$("#appoint-modal").modal("hide");
			$("#alert-modal").modal("show");
			$(".message").html(out.msg);
		}
		if (out.result==0) {
			$("#msg-modal").modal("show");
		}
	});
});