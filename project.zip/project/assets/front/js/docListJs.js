$("#loc-search-form").submit(function(evt){
	evt.preventDefault();
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(){
		window.location.href="front/docSearchList";
	});
});