$("#patient-profile-form,#patient-changepass-form").submit(function(evt){
	evt.preventDefault();
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(out){
		var error=out.errors;
		$(".form-group").find(".text-danger").remove();
		if (out.result==0) {
			for(var i in error){
				$("#"+i).parents(".form-group").append("<span style='font-weight:bold;' class='text-danger'>"+error[i]+"</span>");
			}
		}
		if (out.result==1) {
			$("#alert-msg-patpro,#alert-msg-patpass").html(out.msg).removeClass("hidden").removeClass("alert-danger").addClass("alert-success");
		}
		if (out.result==-1) {
			$("#alert-msg-patpro,#alert-msg-patpass").html(out.msg).removeClass("hidden").addClass("alert-success");	
		}
	})
});