$("#patient-signup-form,#patient-signin-form").submit(function(evt){
	evt.preventDefault();
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(out){
		var error=out.errors;
		$(".form-group").find(".text-danger").remove();
		if (out.result==0) {
			for(var i in error){
				$("#"+i).parents(".form-group").append("<span class='text-danger' style='font-weight:bold;'>"+error[i]+"</span>");
			}
		}
		if (out.result==1) {
			$("#loginPatientModal").modal('show');
			$("#alert-msg").html(out.msg).removeClass("hidden");
			$("#patientSignUpModal").modal('hide');
		}
		if (out.result==-1) {
			$("#patientSignUpModal").modal("show");
			$("alert-msg-signup").html(out.msg).removeClass("hidden");
		}
		if (out.result==2) {
			window.location.href=out.url;
		}
		if (out.result==-2) {
			$("#alert-msg").html(out.msg).removeClass("hidden").removeClass("alert-success").addClass("alert-danger");
		}
		if (out.result==-3) {
			$("#loginPatientModal").modal("hide");
			$("#patientSignUpModal").modal("show");
			$("#alert-msg-signup").html(out.msg).removeClass("hidden").removeClass("alert-success").addClass("alert-warning");
		}
	});
});