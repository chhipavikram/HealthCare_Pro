$("#doc-signup-form,#doc-signin-form").submit(function(evt){
	evt.preventDefault();
	var postdata=$(this).serialize();
	var url=$(this).attr("action");
	$.post(url,postdata,function(out){
		var error=out.errors;
		$(".form-group").find(".text-danger").remove();
		if (out.result==0) {
			for(var i in error){
				$("#"+i).parents(".form-group").append("<span class='text-danger' style='font-weight:bold;'>"+error[i]+"</span>");
			}
		}
		if (out.result==1) {
			$("#loginDoctorModal").modal('show');
			$("#alert-msg-docsignin").html(out.msg).removeClass("hidden").removeClass("alert-danger").addClass("alert-success");
			$("#doctorSignUpModal").modal('hide');
		}
		if (out.result==-1) {
			$("#patientSignUpModal").modal("show");
			$("#alert-msg-docsignup").html(out.msg).removeClass("hidden");
		}
		if (out.result==2) {
			window.location.href=out.url;
		}
		if (out.result==-2) {
			$("#alert-msg-docsignin").html(out.msg).removeClass("hidden").removeClass("alert-success").addClass("alert-danger");
		}
		if (out.result==-3) {
			$("#loginDoctorModal").modal("hide");
			$("#doctorSignUpModal").modal("show");
			$("#alert-msg-docsignup").html(out.msg).removeClass("hidden");
		}
	});
});