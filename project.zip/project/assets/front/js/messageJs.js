$(document).on("submit","#message-send-form,.message-reply-form",function(evt){
	evt.preventDefault();
	var postdata=$(this).serialize();
	var url=$(this).attr("action");
	$.post(url,postdata,function(out){
		if (out.result==1) {
			$(".msg-modal").modal("hide");
			$("#alert-modal").modal("show");
			$(".message").html(out.msg);
		}
		if (out.result==2) {
			$("#alert-msg").html(out.msg).removeClass("alert-danger").removeClass("hidden").addClass("alert-success");
		}
		if (out.result==-2) {
			$("#alert-msg").html(out.msg).removeClass("hidden");
		}
	});
});