$(document).on("change","#state-list",function(){
	var state=$(this).val();
	$("#city-list").empty();
	$.post("doGetCityList",{state_id:state},function(out){
		$.each(out.city,function(k,v){
			$("#city-list").append("<option value='"+v.name+"'>"+v.name+"</option>");
		});
	});
});