$(document).on("submit",".appointment-action",function(evt){
	evt.preventDefault();
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(out){
		if (out.result==1) {
			window.location.href=out.url;
		}
		if (out.result==-1) {
			$("#alert-msg").removeClass("hidden").html(out.msg);
		}
	});
});