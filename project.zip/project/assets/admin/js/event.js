$("#admin-login-form,#admin-change-password-form,#admin-change-profile-form").submit(function(evt){
	evt.preventDefault();
	var form=$(this)[0];
	var url=$(this).attr("action");
	var postdata=$(this).serialize();
	$.post(url,postdata,function(data){
		var error=data.error;
		$(".form-group").find(".text-danger").remove();
		if (data.result==0) {
			for(var i in error){
				$("#"+i).parents(".form-group").append("<span class='text-danger' style='font-weight:bold;'>"+error[i]+"</span>");
			}
		}
		if (data.result==1) {
			window.location.href=data.url;
			$("#alert-msg").html(data.msg).removeClass("hidden").removeClass("alert-warning").addClass("alert-success");
		}
		if (data.result==-1) {
			$("#alert-msg").html(data.msg).removeClass("hidden");
		}
		if (data.result==2) {
			$("#alert-msg").html(data.msg).removeClass("hidden").removeClass("alert-warning").addClass("alert-success");
			form.reset();	
		}
	});
});