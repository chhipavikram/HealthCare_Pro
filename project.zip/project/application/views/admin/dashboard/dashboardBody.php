<div id="body-sec">
	<div class="container-fluid">
		<div class="row">
			<?php 
				echo $sidebar;
				echo $mainsec;
			?>
		</div>
	</div>
</div>