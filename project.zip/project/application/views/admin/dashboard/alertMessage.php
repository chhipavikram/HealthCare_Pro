<div class="alert alert-warning alert-dismissible hidden" role="alert" id="alert-msg">
	<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="Close">&times</span></button>
	hi
</div>