<div class="col-md-4 col-md-offset-4 changePass">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title heading">Change Password</h4>
		</div>
		<div class="panel-body">
			<form id="admin-change-password-form" method="POST" action="<?php echo base_url("admin/do_changePassword"); ?>">
				<div class="form-group">
					<input type="password" name="adminNewPass" id="adminNewPass" class="form-control" placeholder="New Password">
				</div>
				<div class="form-group">
					<input type="password" name="adminConPass" id="adminConPass" class="form-control" placeholder="Confirm Password">
				</div>
				<div class="form-group">
					<input type="submit" name="adminChangePassSub" id="adminChangePassSub" class="btn btn-primary btn-block">
				</div>
			</form>
		</div>
	</div>
</div>