<div class="col-md-6 col-md-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4 class="panel-title heading">Change Profile</h4>
		</div>
		<div class="panel-body">
			<form id="admin-change-profile-form" method="action" action="<?php echo base_url("admin/do_changeProfile"); ?>">
				<div class="form-group">
					<input type="text" name="adminChangeProfileMail" id="adminChangeProfileMail" class="form-control" value="<?php echo $user_info['adminMail'] ?>">
				</div>
				<div class="form-group">
					<input type="text" name="adminChangeProfileNumber" id="adminChangeProfileNumber" class="form-control" value="<?php echo $user_info['adminPhone'] ?>">
				</div>
				<div class="form-group">
					<input type="submit" name="adminChangeProfileSub" id="adminChangeProfileSub" value="Update" class="btn btn-primary btn-block">
				</div>
			</form>
		</div>
	</div>
</div>