<!DOCTYPE html>
<html>
<head>
	<title>yo</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/bootstrap.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/font-awesome.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/admin-dashboard-style.css"); ?>">
</head>
<body>
<div id="topbar">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="menu-list" aria-expanded="false" >
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h3 class="logo-personal">Logo</h3>
			</div>
			<div class="collapse navbar-collapse" id="menu-list">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#">Home</a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
							Profile
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="#">Change Profile</a></li>
							<li><a href="#">Change Password</a></li>
							<li><a href="<?php echo base_url("admin/do_logout"); ?>">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</nav>
</div>
<div id="body-sec">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2 sidenav">
				<ul class="nav nav-sidebar">
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 1</a></li>
					<li><a href="#">Option 1</a></li>
				</ul>
			</div>
			<div class="col-md-10 col-md-offset-2 body-main">
				
			</div>
		</div>
	</div>
</div>
<script src="<?php echo base_url("assets/admin/jquery/jquery.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/admin/js/bootstrap.min.js"); ?>"></script>
</body>
</html>