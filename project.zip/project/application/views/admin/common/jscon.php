
<script src="<?php echo base_url("assets/admin/jquery/jquery.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/admin/js/bootstrap.min.js"); ?>"></script>