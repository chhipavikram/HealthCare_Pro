<div class="col-md-2 sidenav">
	<ul class="nav nav-sidebar">
		<li><a href="#">Doctors</a></li>
		<li><a href="#">Patients</a></li>
		<li><a href="#">Option 1</a></li>
		<li><a href="#">Option 1</a></li>
		<li><a href="#">Option 1</a></li>
		<li><a href="#">Option 1</a></li>
	</ul>
</div>