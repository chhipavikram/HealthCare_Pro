<div class="col-md-10 col-md-offset-2 body-main">
	<?php 
		if (isset($alert)) {
			echo $alert;
		}
		if (isset($pageContent)) {
			echo $pageContent;
		}
	?>
</div>