<div id="topbar">
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="menu-list" aria-expanded="false" >
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h3 class="logo-personal">Logo</h3>
			</div>
			<div class="collapse navbar-collapse" id="menu-list">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="<?php echo base_url("admin/dashboard"); ?>">Home</a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
							Profile
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="<?php echo base_url("admin/change_profile"); ?>">Change Profile</a></li>
							<li><a href="<?php echo base_url("admin/change_password"); ?>">Change Password</a></li>
							<li><a href="<?php echo base_url("admin/do_logout"); ?>">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</nav>
</div>