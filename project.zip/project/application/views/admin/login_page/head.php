<!DOCTYPE html>
<html>
<head>
	<title>yo</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/bootstrap.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/admin-style.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/admin/css/font-awesome.min.css"); ?>">
</head>
<body>