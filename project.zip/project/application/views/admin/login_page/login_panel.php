<div id="admin-login-panel">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h1>Login</h1>
						<p>Enter your account details to login!</p>
					</div>
					<div class="panel-body">
						<div class="hidden alert alert-dismissible alert-warning" id="alert-msg">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<?php
							echo form_open(base_url("admin/do_login"),['id'=>'admin-login-form']);
						?>
							<div class="form-group">
								<div class="input-group">
									<?php
										echo form_input(["type"=>"email" ,"name"=>"admin-login-mail",'id'=>'admin-login-mail', "class"=>"form-control" ,"placeholder"=>"Email"]);
									?>
									<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
								</div>
							</div>
							<div class="form-group">
								<div class="input-group">
									<?php
										echo form_input(["type"=>"password" ,"name"=>"admin-login-pass",'id'=>'admin-login-pass' ,"class"=>"form-control" ,"placeholder"=>"Password"]);
									?>
									<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								</div>
							</div>
							<div class="form-group">
								<?php
									echo form_submit(["name"=>"admin-login-sub" ,"value"=>"Login" ,"class"=>"btn btn-block btn-primary"]);
								?>
							</div>
						<?php echo form_close() ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>