<div id="inboxMsgList">
	<p class="h3 text-center">INBOX</p>
	<div class="row">
		<div class="col-md-5 col-md-offset-2">
			<ul class="nav nav-sidebar">
				<?php
				if (!empty($msgInbox)) {
					foreach ($docTbl as $value) {
						$c=0;
						foreach ($msgInbox as $v) {
							if ($value['tblDocDataId']==$v['msgSendId']) {
								$c++;
							}
						}
						if ($c>0) {
							?>
								<li>
									<form class="message-from" method="POST" action="<?php echo base_url("front/patientDashboardMessage"); ?>">
										<div class="row">
											<div class="col-md-8">
												<?php echo $value['tblDocDataFName']." ".$value['tblDocDataMName']." ".$value['tblDocDataLName']; ?>
											</div>
											<div class="col-md-4">
												<input type="submit" name="seeMsg" id="seeMsg" class="btn btn-block btn-warning" value="Open">
											</div>
										</div>
										<input type="hidden" name="p1" id="p1" value="<?php echo $user_info['tblPatientDataId'] ?>">
										<input type="hidden" name="Typep1" id="Typep1" value="<?php echo "Patient"; ?>">
										<input type="hidden" name="p2" id="p2" value="<?php echo $value['tblDocDataId'] ?>">
										<input type="hidden" name="Typep2" id="Typep2" value="<?php echo "Doctor"; ?>">
									</form>
								</li>
							<?php
						}
					}	
				}else{
					?>
						<p class="h2 text-center">No messages</p>
					<?php
				}
				?>
			</ul>
		</div>
	</div>
</div>