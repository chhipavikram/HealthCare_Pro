<form id="patient-changepass-form" method="POST" action="<?php echo base_url("front/doChangePatientPass"); ?>">
	<input type="hidden" name="patientId" value="<?php echo $user_info['tblPatientDataId']; ?>">
	<p class="h3 text-center" style="font-weight: bold;color: rgb(53,123,53);">Change Password</p>
	<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-patpass">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	</div>
	<div class="form-group">
		<label>New Password:</label>
		<input type="password" name="patientNPass" id="patientNPass" class="form-control" placeholder="New Password">
	</div>
	<div class="form-group">
		<label>Confirm Password:</label>
		<input type="password" name="patientCPass" id="patientCPass" class="form-control" placeholder="Confirm Password">
	</div>
	<div class="form-group">
		<input type="submit" name="patientChangePassSub" id="patientChangePassSub" class="btn btn-lg btn-success">
	</div>
</form>