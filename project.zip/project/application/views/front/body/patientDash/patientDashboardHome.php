<p class="h2 text-center">Welcome!</p>
<?php
	if (isset($user_info)) {
		?>
			<p class="h4 text-center" style="text-transform: uppercase;"><?php echo $user_info['tblPatientDataFName']." ".$user_info['tblPatientDataMName']." ".$user_info['tblPatientDataLName']; ?></p>
		<?php
	}
?>