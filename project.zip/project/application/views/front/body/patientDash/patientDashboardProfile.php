<form id="patient-profile-form" method="POST" action="<?php echo base_url("front/doPatientProfileUpdate"); ?>">
	<p class="h3 text-center" style="font-weight: bold;color: rgb(53,123,53);">My Profile</p>
	<div class="form-group">
		<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-patpro">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		</div>
		<label>Name:</label>
		<div class="form-inline">
			<input type="hidden" name="patientDataId" id="patientDataId" value="<?php if(isset($user_info['tblPatientDataId'])){ echo $user_info['tblPatientDataId']; } ?>">
			<input type="text" name="patientFName" id="patientFName" class="form-control" placeholder="First Name" value="<?php if(isset($user_info['tblPatientDataFName'])){ echo $user_info['tblPatientDataFName']; } ?>">
			<input type="text" name="patientMName" id="patientMName" class="form-control" placeholder="Middle Name" value="<?php if(isset($user_info['tblPatientDataMName'])){ echo $user_info['tblPatientDataMName']; } ?>">
			<input type="text" name="patientLName" id="patientLName" class="form-control" placeholder="Last Name" value="<?php if(isset($user_info['tblPatientDataLName'])){ echo $user_info['tblPatientDataLName']; } ?>">
		</div>	
	</div>
	<div class="form-group">
		<label>Mail:</label>
		<input type="text" name="patientMail" id="patientMail" class="form-control" placeholder="E-Mail" value="<?php if(isset($user_info['tblPatientDataMail'])){ echo $user_info['tblPatientDataMail']; } ?>">
	</div>
	<div class="form-group">
		<label>Phone Number:</label>
		<input type="text" name="patientPno" id="patientPno" class="form-control" placeholder="Phone Number" value="<?php if(isset($user_info['tblPatientDataPNo'])){ echo $user_info['tblPatientDataPNo']; } ?>">
	</div>
	<div class="form-group">
		<label>Address:</label>
		<textarea class="form-control" name="patientAddr" id="patientAddr" class="form-control" placeholder="Address" cols="10" rows="10"><?php if(isset($user_info['tblPatientDataAddr'])){ echo $user_info['tblPatientDataAddr']; } ?></textarea>
	</div>	
	<div class="form-group">
		<input type="submit" name="patientUpdateSub" id="patientUpdateSub" class="btn btn-block btn-lg btn-success" value="UPDATE">
	</div>
</form>