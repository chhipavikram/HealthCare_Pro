<div id="appointment-list">
<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
	<table class="table">
		<tr>
			<th>Doctor Name:</th>
			<th>Clinic Name:</th>
			<th>Address:</th>
			<th>Phone No.:</th>
			<th>Speciality:</th>
			<th>Date:</th>
			<th>Status:</th>
			<th>Action:</th>
		</tr>
		<?php
			foreach ($docData as $value) {
				foreach ($patData as $v) {
					if ($v['appPatType']=='Patient' && $v['appPatId']==$user_info['tblPatientDataId'] && $v['appDocId']==$value['tblDocDataId'] && $v['appStat']!="Canceled") {
						?>
							<tr>
								<td><?php echo $value['tblDocDataFName']." ".$value['tblDocDataMName']." ".$value['tblDocDataLName']; ?></td>
								<td><?php echo $value['tblClinicName']; ?></td>
								<td><?php echo $value['tblClinicAddr'].",".$value['tblClinicState'].",".$value['tblClinicCity']; ?></td>
								<td><?php echo $value['tblDocDataPNo']."/".$value['tblDocDataOffNo']; ?></td>
								<td><?php echo $value['tblDocDataSpeciality']; ?></td>
								<td><?php echo $v['appDate']; ?></td>
								<td><?php echo $v['appStat']; ?></td>
								<td>
									<form class="patapp-cancel-form" method="POST" action="<?php echo base_url("front/doCancelAppointment"); ?>">
										<input type="hidden" name="appStat" id="appStat" value="Canceled">
										<input type="hidden" name="patType" id="patType" value="Patient">
										<input type="hidden" name="patId" id="patId" value="<?php echo $user_info['tblPatientDataId']; ?>">
										<input type="hidden" name="docId" id="docId" value="<?php echo $value['tblDocDataId']; ?>">
										<input type="hidden" name="appDate" id="appDate" value="<?php echo $v['appDate'] ?>">
										<input type="submit" name="appC" id="appC" class="btn btn-block btn-danger" value="Cancel">
									</form>
								</td>
							</tr>
						<?php
					}
				}
			}
		?>
	</table>
</div>