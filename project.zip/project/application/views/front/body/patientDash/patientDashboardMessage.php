<div id="inboxMsgList">
	<p class="h3 text-center">INBOX</p>
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<?php
			$f=0;
				$n=$docTbl['tblDocDataFName']." ".$docTbl['tblDocDataMName']." ".$docTbl['tblDocDataLName'];
				foreach ($message as $value) {
					$f++;
					if ($value['msgRecId']==$user_info['tblPatientDataId'] && $value['msgRecType']=="Patient") {
						?>
							<p style="text-align: left;"><i style="font-weight: bold;"><?php echo $n; ?>:</i><?php echo $value['msgData']; ?></p>
						<?php
					}else{
						?>
							<p style="text-align: right;"><i style="font-weight: bold;">me:</i><?php echo $value['msgData'] ?></p>
						<?php
					}
				}
			?>
			<form class="message-reply-form" method="POST" action="<?php echo base_url("front/doSendMessage"); ?>">
				<input type="hidden" name="sendType" id="sendType" value="Patient">
				<input type="hidden" name="sendId" id="sendId" value="<?php echo $user_info['tblPatientDataId']; ?>">
				<input type="hidden" name="msgParent" id="msgParent" value="<?php echo $f; ?>">
				<input type="hidden" name="recType" id="recType" value="Doctor">
				<input type="hidden" name="recId" id="recId" value="<?php echo $docTbl['tblDocDataId']; ?>">
				<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="form-group">
					<textarea class="form-control" name="message" id="message" cols="70" rows="8" placeholder="Type your message" maxlength="2000"></textarea>
					<i>Not more than 2000 characters...</i>
				</div>
				<div class="form-group">
					<input type="submit" name="replySub" id="replySub" class="btn btn-block btn-success" value="Reply!">
				</div>
			</form>
		</div>
	</div>
</div>