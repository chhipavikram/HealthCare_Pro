<div id="contactus-bar">
		<div class="bar-content">
			<div class="container">
				<div class="section-heading">
					<p class="h1 header-second page-header">Contact Us</p>
				</div>
				<div class="section-divide"></div>
				<div class="section-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3">
							<div class="form-section">
								<form>
									<div class="form-group">
										<input type="text" name="vname" id="vname" class="form-control" placeholder="Name...">
									</div>
									<div class="form-group">
										<input type="text" name="vnum" id="vnum" class="form-control" placeholder="Phone Number...">
									</div>
									<div class="form-group">
										<input type="text" name="vmail" id="vmail" class="form-control" placeholder="Email...">
									</div>
									<div class="form-group">
										<textarea class="form-control" id="vquery" name="vquery" rows="10" cols="5"></textarea>
									</div>
									<div class="form-group">
										<input type="submit" name="vsub" id="vsub" class="btn btn-block btn-success" value="Send">
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>