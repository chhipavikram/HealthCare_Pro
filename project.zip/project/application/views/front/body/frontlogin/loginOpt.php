<div id="loginOptBanner">
	<div class="bar-content" id="loginOptContent">
		<div class="container">
			<div class="row">
				<!-- doctor sign in start -->
				<?php
					echo $docSignIn;
				?>
				<!-- doctor sign in stop -->
				<!-- patient sign in start -->
				<?php
					echo $patSignIn;
				?>
				<!-- patient sign in stop -->
			</div>
			<div class="row">
				<!-- doctor sign up start -->
				<?php
					echo $docSignUp
				?>
				<!-- doctor sign up stop -->
				<!-- patient sign up start -->
				<?php
					echo $patSignUp;
				?>
				<!-- patient sign up stop -->
			</div>
		</div>
	</div>
</div>