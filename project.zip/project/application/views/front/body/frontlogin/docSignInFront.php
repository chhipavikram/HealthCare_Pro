<div class="col-md-4 col-md-offset-2 form-group">
	<button data-toggle="modal" class="btn btn-block btn-lg btn-success" data-target="#loginDoctorModal">Login As Doctor</button>
</div>
<div class="modal fade" id="loginDoctorModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title text-center" style="font-weight: bold; color: rgba(53,123,53,1)">Doctor Sign In</h3>
			</div>
			<div class="modal-body modal-custom">
				<form id="doc-signin-form" method="POST" action="<?php echo base_url("front/doDocSignIn"); ?>">
					<div class="form-group">
						<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-docsignin">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<div class="input-group">
							<span class="input-group-addon" id="docloginmailimg"><i class="fa fa-envelope"></i></span>
							<input type="text" name="docloginmail" id="docloginmail" class="form-control" aria-describedby="docloginmailimg" placeholder="Email...">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon" id="docloginpassimg"><i class="fa fa-lock"></i></span>
							<input type="password" name="docloginpass" id="docloginpass" aria-describedby="docloginpassimg" class="form-control" placeholder="Password...">
						</div>
					</div>
					<div class="form-group">
						<input type="submit" name="docloginsub" id="docloginsub" class="btn btn-block btn-success btn-lg" value="Sign In!">
					</div>
					<div class="form-group">
						<a href="#">Forgot Password?</a>
					</div>
					<div class="form-group">
						<p class="text-center h4" style="font-weight: bold; color: blue;">Sign in Using</p>
						<div class="col-md-6">
							<p class="text-center"><a href="#"><i class="fa fa-facebook" style="font-size: 2vw;"></i></a></p>
						</div>
						<div class="col-md-6">
							<p class="text-center"><a href=""><i class="fa fa-google" style="font-size: 2vw;"></i></a></p>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>