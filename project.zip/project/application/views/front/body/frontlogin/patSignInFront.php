<div class="col-md-4 form-group">
	<button class="btn btn-block btn-success btn-lg" data-toggle="modal" data-target="#loginPatientModal" id="btnPatSignIn">Login as Patient</button>
</div>
<div class="modal fade" id="loginPatientModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title text-center" style="font-weight: bold;color: rgba(53,123,53,1);">Patient Sign In</h3>
			</div>
			<div class="modal-body modal-custom">
				<form id="patient-signin-form" method="POST" action="<?php echo base_url("front/doPatientSignIn"); ?>">
					<div class="alert alert-success alert-dismissible hidden" role="alert" id="alert-msg">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon" id="patientLoginMailImg"><i class="fa fa-envelope"></i></span>
							<input type="text" name="patientLoginMail" id="patientLoginMail" aria-describedby="patientLoginMailImg" class="form-control" placeholder="Email...">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon" id="patientLoginPassImg"><i class="fa fa-lock"></i></span>
							<input type="password" name="patientLoginPass" id="patientLoginPass" class="form-control" class="form-control" placeholder="Password..." aria-describedby="patientLoginPassImg">
						</div>
					</div>
					<div class="form-group">
						<input type="submit" name="patientLoginSub" id="patientLoginSub" class="btn btn-lg btn-block btn-success" value="Sign In!">
					</div>
					<div class="form-group">
						<a href="#">Forgot Password</a>
					</div>
					<div class="form-group">
						<p class="h4 text-center" style="font-weight: bold;color: blue;">Sign In Using</p>
						<div class="col-md-6">
							<p class="text-center"><a href="#"><i class="fa fa-facebook" style="font-size: 2vw"></i></a></p>
						</div>
						<div class="col-md-6">
							<p class="text-center"><a href="#"><i class="fa fa-google" style="font-size: 2vw;"></i></a></p>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>