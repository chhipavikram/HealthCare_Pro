<div class="col-md-4 form-group">
	<button class="btn btn-lg btn-block btn-warning" data-toggle="modal" data-target="#patientSignUpModal">Sign up as Patient!</button>
</div>
<div class="modal fade" id="patientSignUpModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title text-center" style="font-weight: bold;color: #eea236;">Patient Sign Up!</h3>
			</div>
			<div class="modal-body modal-custom" id="">
				<form id="patient-signup-form" method="POST" action="<?php echo base_url("front/doPatientSignUp"); ?>">
					<div class="alert alert-warning alert-dismissible hidden" role="alert" id="alert-msg-signup">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="form-group">
						<label>First Name:</label>
						<input type="text" name="patRegFName" id="patRegFName" class="form-control" placeholder="First Name...">
					</div>
					<div class="form-group">
						<label>Middle Name:</label>
						<input type="text" name="patRegMName" id="patRegMName" class="form-control" placeholder="Middle Name...">
					</div>
					<div class="form-group">
						<label>Last Name:</label>
						<input type="text" name="patRegLName" id="patRegLName" class="form-control" placeholder="Last Name...">
					</div>
					<div class="form-group">
						<label>Email:</label>
						<input type="text" class="form-control" name="patRegMail" id="patRegMail" placeholder="Email...">
					</div>
					<div class="form-group">
						<label>Phone No:</label>
						<input type="text" name="patRegNum" id="patRegNum" class="form-control" placeholder="Phone Number...">
					</div>
					<div class="form-group">
						<label>Password:</label>
						<input type="password" name="patRegPass" id="patRegPass" class="form-control" placeholder="Password">
					</div>
					<div class="form-group">
						<label>Confirm Password:</label>
						<input type="password" name="patRegConPass" id="patRegConPass" class="form-control" placeholder="Confirm Password">
					</div>
					<div class="form-group">
						<input type="submit" name="patRegSub" id="patRegSub" class="btn btn-block btn-lg btn-warning" data-target="#loginPatientModal">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>