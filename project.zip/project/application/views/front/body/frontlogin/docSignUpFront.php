<div class="col-md-4 col-md-offset-2 form-group">
	<button class="btn btn-lg btn-block btn-warning" data-toggle="modal" data-target="#doctorSignUpModal">Sign Up as Doctor!</button>
</div>
<div class="modal fade" id="doctorSignUpModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title text-center" style="font-weight: bold;color: #eea236;">Doctor Sign up!</h3>
			</div>
			<div class="modal-body modal-custom">
				<form id="doc-signup-form" method="POST" action="<?php echo base_url("front/doDocSignUp"); ?>">
					<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-docsignup">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="form-group">
						<label>First Name:</label>
						<input type="text" name="docRegFName" id="docRegFName" class="form-control" placeholder="First Name...">
					</div>
					<div class="form-group">
						<label>Middle Name:</label>
						<input type="text" name="docRegMName" id="docRegMName" class="form-control" placeholder="Middle Name...">
					</div>
					<div class="form-group">
						<label>Last Name:</label>
						<input type="text" name="docRegLName" id="docRegLName" class="form-control" placeholder="Last Name...">
					</div>
					<div class="form-group">
						<label>Email:</label>
						<input type="text" class="form-control" name="docRegMail" id="docRegMail" placeholder="Email...">
					</div>
					<div class="form-group">
						<label>Phone No:</label>
						<input type="text" name="docRegNum" id="docRegNum" class="form-control" placeholder="Phone Number...">
					</div>
					<div class="form-group">
						<label>Password:</label>
						<input type="password" name="docRegPass" id="docRegPass" class="form-control" placeholder="Password">
					</div>
					<div class="form-group">
						<label>Confirm Password:</label>
						<input type="password" name="docRegConPass" id="docRegConPass" class="form-control" placeholder="Confirm Password">
					</div>
					<div class="form-group">
						<input type="submit" name="docRegSub" id="docRegSub" class="btn btn-block btn-lg btn-warning">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>