	<div id="article-bar">
		<div class="bar-content">
			<div class="container">
				<div class="section-heading">
					<p class="h1 header-second page-header">Articles from renowned specialists!</p>
				</div>
				<div class="section-divide"></div>
				<div class="section-content">
					<div class="row">
						<div class="col-md-4">
							<div class="article-link">
								<a href="#">
									<div class="article-heading">
										<p class="h2 article-head">Healthy food for heart!</p>
									</div>
									<div class="section-divide"></div>
									<div class="article-image">
										<img class="img-responsive img-circle" src="<?php echo base_url("assets/front/images/heart-food.jpg"); ?>">
									</div>
								</a>
							</div>
						</div>
						<div class="col-md-4">
							<div class="article-link">
								<a href="#">
									<div class="article-heading">
										<p class="h2 article-head">What to eat when?</p>
									</div>
									<div class="section-divide"></div>
									<div class="article-image">
										<img class="img-responsive img-circle" src="<?php echo base_url("assets/front/images/diet-clock.jpg"); ?>">
									</div>
								</a>
							</div>
						</div>
						<div class="col-md-4">
							<div class="article-link">
								<a href="#">
									<div class="article-heading">
										<p class="h2 article-head">Alchohol and heart health!</p>
									</div>
									<div class="section-divide"></div>
									<div class="article-image">
										<img class="img-responsive img-circle" src="<?php echo base_url("assets/front/images/Alcohol.jpg"); ?>">
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>