	<div id="step-bar">
		<div class="container">
			<div class="section-heading">
				<p class="h1 header page-header">How to get an appointment?</p>
			</div>
			<div class="section-divide"></div>
			<div class="section-content">
				<div class="row">
					<div class="col-md-3">
						<p class="step-icon">
							<i class="fa fa-search"></i>
						</p>
						<p class="step-text">
							Search your location!
						</p>
					</div>
					<div class="col-md-3">
						<p class="step-icon">
							<i class="fa fa-user-md"></i>
						</p>
						<p class="step-text">
							Find your doctor!
						</p>
					</div>
					<div class="col-md-3">
						<p class="step-icon">
							<i class="fa fa-calendar"></i>
						</p>
						<p class="step-text">
							Set an appointment!
						</p>
					</div>
					<div class="col-md-3">
						<p class="step-icon">
							<i class="fa fa-stethoscope"></i>
						</p>
						<p class="step-text">
							Get yourself checked!
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>