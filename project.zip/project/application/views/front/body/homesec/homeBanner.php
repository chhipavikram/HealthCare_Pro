<div id="banner">
		<div class="jumbotron">
			<div class="container">
				<h1>Your Health Our Concern!</h1>
			</div>
			<div id="search-form" class="col-md-8 col-md-offset-2">
				<form class="form-inline" action="<?php echo base_url("front/docSearchList"); ?>" method="POST">
					<div id="state-search" class="form-group col-md-5">
						<select class="state-list" id="statelist" name="statelist" placeholder="--Select State--">
							<?php
								foreach ($city as $value) {
									?>
										<option value="<?php echo $value['state_id']; ?>"><?php echo $value['state_name']; ?></option>
									<?php
								}
							?>
						</select>
					</div>
					<div id="city-search" class="form-group col-md-5">
						<select class="city-list form-control" id="citylist" name="citylist" style="width: 100%;">
							<option value="0">--Select City--</option>
							<!-- city listing -->
						</select>
					</div>
					<div class="form-group col-md-2">
						<input type="submit" name="locSearchSub" id="locSearchSub" class="btn btn-block btn-success" value="Search!">
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="modal fade" id="suggestionmodal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<p class="h4 modal-title suggestion text-center">Login/Register to search!</p>
				</div>
				<div class="modal-body modal-custom">
					<div class="col-md-6">
						<a class="btn btn-success btn-block" href="<?php echo base_url("front/login_option"); ?>">Yes</a>
					</div>
					<div class="col-md-6">
						<a class="btn btn-danger btn-block" href="<?php echo base_url("front"); ?>">No</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- <?php
								/*foreach ($city as $value)*/ {
									?>
										<option value="<?php /*echo $value['city_name']; ?>"><?php echo $value['city_name'];*/ ?></option>
									<?php		
								}
							?> -->