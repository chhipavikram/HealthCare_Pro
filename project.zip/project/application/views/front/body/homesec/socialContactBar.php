<div id="social-bar">
		<div class="container">
			<div class="section-heading">
				<p class="h1 header page-header">Find Us</p>
			</div>
			<div class="section-divide"></div>
			<div class="section-content">
				<div class="row">
					<div class="col-md-4">
						<p style="text-align: center; font-size: 5vw;">
							<a href=""><i class="fa fa-facebook" style="color:#3366ff; "></i></a>
						</p>
					</div>
					<div class="col-md-4">
						<p style="text-align: center; font-size: 5vw;">
							<a href=""><i class="fa fa-google" style="color: #e60000;"></i></a>
						</p>
					</div>
					<div class="col-md-4">
						<p style="text-align: center; font-size: 5vw;">
							<a href="#"><i class="fa fa-twitter" style="color: #6699ff;"></i></a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>