	<div id="about-us-bar">
		<div class="container">
			<div class="section-heading">
				<p class="h1 header page-header">About Us</p>
			</div>
			<div class="section-divide"></div>
			<div class="section-content">
				<div class="row">
					<div class="col-md-6">
						<img class="img-responsive" src="<?php echo base_url("assets/front/images/docgrp.jpg"); ?>">
					</div>
					<div class="col-md-6">
						<p class="content">We are a vibrant group of developers who have developed this web site in order to provide users the facility to find nearest health care centers and and other health care facilities.</p>
						<p class="content">Health tips are also available and users may consult online with the doctors available.</p>
						<p class="content">Provides a platform to budding health care specialists to showcase their facilities and efficiency</p>
					</div>
				</div>
			</div>
		</div>
	</div>