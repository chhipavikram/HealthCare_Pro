<form id="doc-profile-form" method="POST" action="<?php echo base_url("front/doDocProfileUpdate"); ?>">
	<p class="h3 text-center" style="font-weight: bold;color: rgb(53,123,53);">My Profile</p>
	<div class="form-group">
		<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-docpro">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		</div>
		<label>Name:</label>
		<div class="form-inline">
			<input type="hidden" name="docDataId" id="docDataId" value="<?php if(isset($user_info['tblDocDataId'])){ echo $user_info['tblDocDataId']; } ?>">
			<input type="text" name="docFName" id="docFName" class="form-control" placeholder="First Name" value="<?php if(isset($user_info['tblDocDataFName'])){ echo $user_info['tblDocDataFName']; } ?>">
			<input type="text" name="docMName" id="docMName" class="form-control" placeholder="Middle Name" value="<?php if(isset($user_info['tblDocDataMName'])){ echo $user_info['tblDocDataMName']; } ?>">
			<input type="text" name="docLName" id="docLName" class="form-control" placeholder="Last Name" value="<?php if(isset($user_info['tblDocDataLName'])){ echo $user_info['tblDocDataLName']; } ?>">
		</div>	
	</div>
	<div class="form-group">
		<label>Mail:</label>
		<input readonly="readonly" type="text" name="docMail" id="docMail" class="form-control" placeholder="E-Mail" value="<?php if(isset($user_info['tblDocDataMail'])){ echo $user_info['tblDocDataMail']; } ?>">
	</div>
	<div class="form-group">
		<label>Phone Number:</label>
		<input type="text" name="docPno" id="docPno" class="form-control" placeholder="Phone Number" value="<?php if(isset($user_info['tblDocDataPNo'])){ echo $user_info['tblDocDataPNo']; } ?>">
	</div>
	<div class="form-group">
		<label>Address:</label>
		<textarea class="form-control" name="docAddr" id="docAddr" class="form-control" placeholder="Address" cols="6" rows="6"><?php if(isset($user_info['tblDocDataAddr'])){ echo $user_info['tblDocDataAddr']; } ?></textarea>
	</div>	
	<div class="form-group">
		<input type="submit" name="docUpdateSub" id="docUpdateSub" class="btn btn-block btn-lg btn-success" value="UPDATE">
	</div>
</form>