<div class="col-md-10 col-md-offset-2">
	<ul class="options">
		<li><a href="#" data-toggle="modal" data-target="#clinicDetModal">Office Details</a></li>
		<li><a href="#" data-toggle="modal" data-target="#docQualModal">Qualification</a></li>
	</ul>
</div>


<!-- office detail modal start -->

<div class="modal fade" id="clinicDetModal">
	<div class="modal-dialog">
		<div class="modal-content modal-content-custom">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" style="color: red">&times;</button>
				<h3 class="text-center modal-title" style="color: #eea236;">Office Details</h3>
			</div>
			<div class="modal-body modal-custom">
				<form id="doc-clinic-addr-form" method="POST" action="<?php echo base_url("front/doAddClinicDet"); ?>">
					<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
					<div class="form-group">
						<input type="text" name="docClinicName" id="docClinicName" placeholder="Hospital Name/Clinic Name" class="form-control" value="<?php if(isset($docClinic['tblClinicName'])){ echo $docClinic['tblClinicName']; } ?>">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrA" id="docClinicAddrA" placeholder="Address Line 1..." class="form-control" maxlength="100">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrB" id="docClinicAddrB" placeholder="Address Line 2..." class="form-control" maxlength="100">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrC" id="docClinicAddrC" placeholder="Address Line 3..." class="form-control" maxlength="100">
					</div>
					<div class="form-group col-md-6">
						<label style="color: #eea236;">State:</label>
						<select class="state-list" name="state-list" id="state-list">
							<?php
								foreach ($states as $value) {
									?>
										<option value="<?php echo $value['state_id']; ?>" <?php if(isset($docClinic['tblClinicState']) && $docClinic['tblClinicState']==$value['state_id']){ echo "selected"; } ?>><?php echo $value['state_name']; ?></option>
									<?php
								}
							?>
						</select>
					</div>
					<div class="form-group col-md-6">
						<label style="color: #eea236;">City:</label>
						<select class="city-list form-control" id="city-list" name="city-list">
							<option value="0">--select city--</option>
						</select>
					</div>
					<div class="form-group">
						<input type="text" name="docClinicPin" id="docClinicPin" class="form-control" maxlength="6" placeholder="PIN Code..." value="<?php if(isset($docClinic['tblClinicPin'])){ echo $docClinic['tblClinicPin']; } ?>">
					</div>
					<div class="form-group">
						<div class="col-md-4 col-md-offset-4">
							<input type="submit" name="docClinicDetSub" id="docClinicDetSub" class="btn btn-lg btn-block btn-warning" value="Update">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<!-- office detail modal close -->

<!-- qualification detail modal start -->

<div class="modal fade" id="docQualModal">
	<div class="modal-dialog">
		<div class="modal-content modal-content-custom">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h3 class="text-center modal-title" style="color: rgb(69,142,203); font-weight: bold;">Your Qualifications!</h3>
			</div>
			<div class="modal-body modal-custom">
				<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-docq">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<form id="qual-list-form" method="POST" action="<?php echo base_url('front/doAddDocQual'); ?>">
					<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
					<div class="form-group" id="specialityddn">
						<label style="font-weight: bold;color:rgb(69,142,203); ">Select Your Specialization</label>
						<select class="docSpeciality" id="docSpeciality" name="docSpeciality">
							<?php
								foreach ($speciality as $value) {
									?>
										<option value="<?php echo $value['tblDocSpecName'] ?>" <?php if(isset($user_info['tblDocDataSpeciality']) && $user_info['tblDocDataSpeciality']==$value['tblDocSpecName']){ echo "selected"; } ?> ><?php echo $value['tblDocSpecName'] ?></option>
									<?php
								}
							?>
						</select>
					</div>
					<div class="form-group" id="qualificationddn">
						<label style="font-weight: bold;color:rgb(69,142,203); ">Select Your Qualifications</label>
						<select class="qual-list" name="qual-list[]" id="qual-list" multiple="multiple">
							<?php
								foreach ($qual as $value) {
									?>
										<option value="<?php echo $value['tblDocDegName']; ?>"><?php echo $value['tblDocDegName']; ?></option>
									<?php
								}
							?>
						</select>
					</div>
					<div class="form-group col-md-4 col-md-offset-4">
						<input type="submit" name="docQualSub" id="docQualSub" class="btn btn-block btn-primary btn-lg" value="Add">
					</div>
				</form>
				<div class="form-group" id="qual-list-div">
					<?php
						if (isset($user_info['tblDocDataQual'])) {
							$q=explode(",", $user_info['tblDocDataQual']);
						}
					?>
					<table id="qual-list-tbl" class="table">
						<tr>
							<td style="color: rgb(69,142,203); font-weight: bold;">Qualification Name</td>
							<td style="color: rgb(69,142,203); font-weight: bold;">Action</td>
						</tr>
						<?php
							if (isset($user_info['tblDocDataQual'])) {
								foreach ($q as $value) {
									?>										
										<tr>
											<form id="qualSec" class="qualSec" method="POST" action="<?php echo base_url("front/doDeleteDocQual"); ?>">
												<td>
													<input type="hidden" name="qualVal" class="qualVal" id="qualVal" value="<?php echo $value; ?>">
													<p style='color:#337ab7;font-weight=bold;' class="qualValp"><?php echo $value; ?></p>
												</td>
												<td>
													<input type="submit" name="qualDel" id="qualDel" class="btn btn-danger" value="Delete">
												</td>
											</form>
										</tr>
									<?php
								}
							}
						?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- qualification detail modal close -->