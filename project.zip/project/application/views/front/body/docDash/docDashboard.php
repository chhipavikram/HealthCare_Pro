<div id="docDashboard">
	<div class="myDashContent">
		<div class="container myPanel">
			<div class="row">
				<div class="col-md-2 col-sm-2 col-xs-2 col-lg-2 sidenav">
					<!-- doctor dashboard side menu start -->
					<ul class="nav nav-sidebar">
						<li><a href="<?php echo base_url("front/docDashboard"); ?>"><i class="fa fa-home"></i>  Home</a></li>
						<li><a href="<?php echo base_url("front/docDashboardInbox"); ?>"><i class="fa fa-envelope"></i>  Inbox</a></li>
						<li><a href="<?php echo base_url("front/docDashboardProfile"); ?>"><i class="fa fa-user"></i>  My Profile</a></li>
						<li><a href="<?php echo base_url("front/docDashboardOficialInfo"); ?>"><i class="fa fa-info-circle"></i>  Official Information</a></li>
						<li><a href="<?php echo base_url("front/docDashboardAppointment"); ?>"><i class="fa fa-calendar-plus-o"></i>  My Appointments</a></li>
						<li><a href="<?php echo base_url("front/docOwnAppointment"); ?>"><i class="fa fa-calendar-check-o">  Own Appointments</i></a></li>
						<li><a href="<?php echo base_url("front/docDashboardSettings"); ?>"><i class="fa fa-cogs"></i>  Settings</a></li>
					</ul>
					<!-- patient dashboard side menu stop -->
				</div>
				<div class="col-md-8 col-sm-8 col-xs-8 col-xs-8">
					<!-- doctor dashboard central data start -->
					<?php
						echo $docDashBody;
					?>
					<!-- doctor dashboard central data stop -->
				</div>
				<!-- doctor dashboard profile picture start-->
				<div class="col-md-2 col-sm-2 col-xs-2 col-lg-2">
					<img src="<?php echo base_url("assets/front/images/ghost.png"); ?>" class="img-responsive user-image" title="user image" width="100px" height="100px">
					<div id="modalbtn" style="padding-top: 5px;">
						<button class="btn btn-success" data-toggle="modal" data-target="#docImgUploadModal">Upload New Image</button>
					</div>
				</div>
				<!-- doctor dashboard profile picture stop -->
				<div class="modal fade" id="docImgUploadModal">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button class="close" data-dismiss="modal">&times;</button>
								<p class="text-center h2">Browse an image!</p>
							</div>
							<div class="modal-body modal-custom">
								<form id="doc-upload-img-form" enctype="multipart/form-data">
									<div class="form-group">
										<input type="file" name="docImg" id="docImg" class="form-control">
									</div>
									<div class="form-group">
										<input type="submit" name="docImgSub" id="docImgSub" class="btn btn-success btn-lg" value="Upload">
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>