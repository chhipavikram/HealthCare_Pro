<p class="text-center h1">Welcome!</p>
<?php
	if (isset($user_info)) {
		?>
			<p class="h4 text-center" style="text-transform: uppercase;"><?php echo $user_info['tblDocDataFName']." ".$user_info['tblDocDataMName']." ".$user_info['tblDocDataLName']; ?></p>
		<?php
		if (empty($docClinicDet)) {
			?>
				<p class="h4" style="font-weight: bold;color: red;">**Kindly Enter Your Clinic Details. If Not Done, Your Name Would Not Be Enlisted In The Search</p>
			<?php
		}
	}
?>