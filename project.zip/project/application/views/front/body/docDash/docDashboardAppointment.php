<div id="appointment-list">
<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
	<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
	<table class="table">
		<tr>
			<th>Patient Name:</th>
			<th>Phone No.:</th>
			<th>Date:</th>
			<th colspan="2">Action</th>
		</tr>
		<?php
			foreach ($patData as $value) {
				if ($value['appPatType']=="Patient" && $value['appDocId']==$user_info['tblDocDataId'] && $value['appStat']!="Canceled") {
					?>
						<tr>
							<td><?php echo $value['tblPatientDataFName']." ".$value['tblPatientDataMName']." ".$value['tblPatientDataLName']; ?></td>
							<td><?php echo $value['tblPatientDataPNo']; ?></td>
							<td><?php echo $value['appDate']; ?></td>
							<td>
								<?php
									if ($value['appStat']=="Awaited") {
										?>
											<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
												<input type="hidden" name="patType" id="patType" value="Patient">
												<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblPatientDataId']; ?>">
												<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
												<input type="hidden" name="appStat" id="appStat" value="Confirmed">
												<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
												<input type="submit" name="btnAppC" id="btnAppC" class="btn btn-success btn-block" value="Confirm">
											</form>
										<?php
									}elseif($value['appStat']=="Confirmed"){
										?>
											<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
												<input type="hidden" name="patType" id="patType" value="Patient">
												<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblPatientDataId']; ?>">
												<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
												<input type="hidden" name="appStat" id="appStat" value="Awaited">
												<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
												<input type="submit" name="btnAppH" id="btnAppH" class="btn btn-warning btn-block" value="Hold">
											</form>
										<?php
									}
								?>
							</td>
							<td>
								<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
									<input type="hidden" name="patType" id="patType" value="Patient">
									<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblPatientDataId']; ?>">
									<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
									<input type="hidden" name="appStat" id="appStat" value="Canceled">
									<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
									<input type="submit" name="btnAppR" id="btnAppR" class="btn btn-danger btn-block" value="Reject">
								</form>
							</td>
						</tr>
					<?php
				}
			}
			foreach ($patDocData as $value) {
				if ($value['appPatType']=="Doctor" && $value['appDocId']==$user_info['tblDocDataId'] && $value['appStat']!="Canceled") {
					?>
						<tr>
							<td><?php echo $value['tblDocDataFName']." ".$value['tblDocDataMName']." ".$value['tblDocDataLName']; ?></td>
							<td><?php echo $value['tblDocDataPNo']; ?></td>
							<td><?php echo $value['appDate']; ?></td>
							<td>
								<?php
									if ($value['appStat']=="Awaited") {
										?>
											<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
												<input type="hidden" name="patType" id="patType" value="Doctor">
												<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblDocDataId']; ?>">
												<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
												<input type="hidden" name="appStat" id="appStat" value="Confirmed">
												<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
												<input type="submit" name="btnAppC" id="btnAppC" class="btn btn-success btn-block" value="Confirm">
											</form>
										<?php
									}elseif($value['appStat']=="Confirmed"){
										?>
											<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
												<input type="hidden" name="patType" id="patType" value="Doctor">
												<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblDocDataId']; ?>">
												<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
												<input type="hidden" name="appStat" id="appStat" value="Awaited">
												<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
												<input type="submit" name="btnAppH" id="btnAppH" class="btn btn-warning btn-block" value="Hold">
											</form>
										<?php
									}
								?>
							</td>
							<td>
								<form class="appointment-action" method="POST" action="<?php echo base_url("front/doUpdateAppointmentStatus"); ?>">
									<input type="hidden" name="patType" id="patType" value="Doctor">
									<input type="hidden" name="patId" id="patId" value="<?php echo $value['tblDocDataId']; ?>">
									<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
									<input type="hidden" name="appStat" id="appStat" value="Canceled">
									<input type="hidden" name="appDate" id="appDate" value="<?php echo $value['appDate'] ?>">
									<input type="submit" name="btnAppR" id="btnAppR" class="btn btn-danger btn-block" value="Reject">
								</form>
							</td>
						</tr>
					<?php
				}
			}
		?>
	</table>
</div>