<div id="office-detail">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<form id="doc-clinic-addr-form" method="POST" action="<?php echo base_url("front/doAddClinicDet"); ?>">
					<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<input type="hidden" name="docId" id="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
					<div class="form-group">
						<input type="text" name="docClinicName" id="docClinicName" placeholder="Hospital Name/Clinic Name" class="form-control">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrA" id="docClinicAddrA" placeholder="Address Line 1..." class="form-control" maxlength="100">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrB" id="docClinicAddrB" placeholder="Address Line 2..." class="form-control" maxlength="100">
					</div>
					<div class="form-group">
						<input type="text" name="docClinicAddrC" id="docClinicAddrC" placeholder="Address Line 3..." class="form-control" maxlength="100">
					</div>
					<div class="form-group col-md-6">
						<label style="color: #eea236;">State:</label>
						<select class="state-list" name="state-name" id="state-name">
							<?php
								foreach ($states as $value) {
									?>
										<option value="<?php echo $value['state_id']; ?>"><?php echo $value['state_name']; ?></option>
									<?php
								}
							?>
						</select>
					</div>
					<div class="form-group col-md-6">
						<label style="color: #eea236;">City:</label>
						<select class="city-list form-control" id="citylist" name="city-name">
							
						</select>
					</div>
					<div class="form-group">
						<input type="text" name="docClinicPin" id="docClinicPin" class="form-control" maxlength="6" placeholder="PIN Code...">
					</div>
					<div class="form-group">
						<div class="col-md-4 col-md-offset-4">
							<input type="submit" name="docClinicDetSub" id="docClinicDetSub" class="btn btn-lg btn-block btn-warning" value="Update">
						</div>
					</div>
				</form>
		</div>
	</div>
</div>