<div class="col-md-10 col-md-offset-2">
	<ul class="options">
		<li><a href="<?php echo base_url("front/docDashboardChangePass"); ?>">Change Password</a></li>
		<li><a href="#" data-toggle="modal" data-target="#deleteConfirmOptionModal">Delete Account</a></li>
	</ul>
</div>
<div class="modal fade" id="deleteConfirmOptionModal">
	<div class="modal-dialog">
		<div class="modal-content modal-content-custom">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h3 class="text-center modal-title" style="color: #5cb85c;">Are you sure you want to delete your account?</h3>
			</div>
			<div class="modal-body modal-custom">
				<div class="col-md-6">
					<a href="<?php echo base_url("front/docDeleteAccount"); ?>" class="btn btn-danger btn-lg btn-block"><i class="fa fa-check"></i> Yes</a>
				</div>
				<div class="col-md-6">
					<a href="<?php echo base_url("front/docDashboardSettings"); ?>" class="btn btn-lg btn-block btn-success"><i class="fa fa-times"></i> No</a>
				</div>
			</div>
		</div>
	</div>
</div>