<form id="doc-changepass-form" method="POST" action="<?php echo base_url("front/doChangeDocPass"); ?>">
	<input type="hidden" name="docId" value="<?php echo $user_info['tblDocDataId']; ?>">
	<p class="h3 text-center" style="font-weight: bold;color: rgb(53,123,53);">Change Password</p>
	<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg-docpass">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	</div>
	<div class="form-group">
		<label>New Password:</label>
		<input type="password" name="docNPass" id="docNPass" class="form-control" placeholder="New Password">
	</div>
	<div class="form-group">
		<label>Confirm Password:</label>
		<input type="password" name="docCPass" id="docCPass" class="form-control" placeholder="Confirm Password">
	</div>
	<div class="form-group">
		<input type="submit" name="docChangePassSub" id="docChangePassSub" class="btn btn-lg btn-success">
	</div>
</form>