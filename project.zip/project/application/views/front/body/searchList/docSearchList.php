<div id="doctor-list-banner">
	<div class="myDashContent">
		<div id="doctor-list-content">
			<div class="container">
				<div id="doctor-search-panel">
					<form class="form-inline" method="POST" action="<?php echo base_url("front/docSearchList") ?>">
						<div class="state-search col-md-3 col-md-offset-1" id="state-search">
							<select class="state-list" id="statelist" name="statelist">
								<?php
									foreach ($state as $value) {
										?>
											<option value="<?php echo $value['state_name'] ?>" <?php if($stateSel==$value['state_id']){ echo "selected"; } ?>><?php echo $value['state_name']; ?></option>
										<?php
									}
								?>
							</select>
						</div>
						<div class="city-search col-md-3" id="city-search">
							<select class="city-list form-control" id="citylist" name="citylist" style="width: 100%;">
								<option value="">--Select City--</option>
								<?php
									foreach ($city as $value) {
										?>
											<option value="<?php echo $value['name']; ?>" <?php if($citySel==$value['name']){ echo "selected"; } ?>><?php echo $value['name']; ?></option>
										<?php
									}
								?>
							</select>
						</div>
						<div class="speciality-search col-md-3" id="speciality-search">
							<select id="specialitylist" class=" speciality-list" name="specialitylist">
								<option value="0">--select speciality--</option>
								<?php
									foreach ($speciality as $value) {
										?>
											<option value="<?php echo $value['tblDocSpecName']; ?>" <?php if(isset($specSel) && $specSel==$value['tblDocSpecName']){ echo "selected"; } ?> ><?php echo $value['tblDocSpecName'] ?></option>
										<?php
									}
								?>
							</select>
						</div>
						<div class="search-btn col-md-1" id="search-btn">
							<button class="btn btn-block btn-success"><i class="fa fa-search"></i></button>
						</div>
					</form>
				</div>
				<div id="doctor-search-list">
					<div id="doc-search-table">
						<?php
						if ($docData==0) {
							?>
								<div id="doc-search-result-sec" class="doc-search-result-sec col-md-10 col-md-offset-1">
									<h2 style="color: red;font-weight: bold;">No Result Found</h2>		
								</div>
							<?php
						}else{
							foreach ($docData as $value) {
								?>
									<div id="doc-search-result-sec" class="doc-search-result-sec col-md-10 col-md-offset-1">
										<div id="doc-img" class="col-md-3">
											<img src="<?php if(isset($value['tblDocDataImg'])){ echo base_url(""); }else{ echo base_url("assets/front/images/ghost.png"); } ?>" width="120" height="120" class="doc-img-box">
										</div>
										<div id="doc-detail" class="col-md-6">
											<table class="doc-detail-table">
												<tr>
													<td><p style="text-transform: uppercase; font-weight: bold;"><?php echo "Dr. ".$value['tblDocDataFName']." ".$value['tblDocDataMName']." ".$value['tblDocDataLName']; ?></p></td>
												</tr>
												<tr>
													<td><b><?php echo $value['tblDocDataSpeciality']; ?></b></td>
												</tr>
												<tr>
													<td>Qualifications: <?php echo $value['tblDocDataQual']; ?></td>
												</tr>
												<tr>
													<td>Office Number: <?php echo $value['tblDocDataOffNo']; ?></td>
												</tr>
												<tr>
													<td><span style="font-weight: bold;">Address:-</span></td>
												</tr>
												<tr>
													<td>Clinic Name: <?php echo $value['tblClinicName'] ?></td>
												</tr>
												<tr>
													<td><?php echo $value['tblClinicAddr'].",".$value['tblClinicCity'].",".$value['tblClinicState'].",Pin:".$value['tblClinicPin']; ?></td>
												</tr>
											</table>
										</div>
										<div id="doc-facility" class="col-md-3">
											<ul class="sidenav nav">
												<form id="msg-check-form" method="POST" action="<?php echo base_url("front/doCheckUser"); ?>">
													<li><input type="submit" name="checkUserTypeSub" id="checkUserTypeSub" class="btn btn-warning btn-block" value="Send Message"></li>
													<?php
														if ($this->session->has_userdata("docMail") || $this->session->has_userdata("patientMail")) {
															if ($this->session->has_userdata("docMail") && $user_info['tblDocDataId']==$value['tblDocDataId']) {
																?>
																	<input type="hidden" name="userType" id="userType" value="13">
																<?php	
															}else{
																?>
																	<input type="hidden" name="userType" id="userType" value="2">
																<?php
															}
														}else{
															?>
																<input type="hidden" name="userType" id="userType" value="0">
															<?php
														}
													?>
												</form>
												<form id="login-check-form" method="POST" action="<?php echo base_url("front/doCheckUser"); ?>">
													<li><input type="submit" name="checkUserTypeSub" id="checkUserTypeSub" class="btn btn-success btn-block" value="Set Appointment"></li>
													<?php
														if ($this->session->has_userdata("docMail") || $this->session->has_userdata("patientMail")) {
															if ($this->session->has_userdata("docMail") && $user_info['tblDocDataId']==$value['tblDocDataId']) {
																?>
																	<input type="hidden" name="userType" id="userType" value="13">
																<?php	
															}else{
																?>
																	<input type="hidden" name="userType" id="userType" value="1">
																<?php
															}
														}else{
															?>
																<input type="hidden" name="userType" id="userType" value="0">
															<?php
														}
													?>
												</form>
												<li><a href="#"><i class="fa fa-star">  Give Your Rating</i></a></li>
												<li>Rate: <?php echo $value['tblDocDataRate']; ?>/10</li>
											</ul>
										</div>
									</div>
									<div id="appoint-modal" class="modal fade">
										<div class="modal-dialog">
											<div class="modal-content">
												<div class="modal-header">
													<button class="close" data-dismiss="modal">&times;</button>
													<p class="text-center h3" style="font-weight: bold;color: #5cb85c;">Select apointment date!</p>
												</div>
												<div class="modal-body">
													<form id="appointment-final-form" method="POST" action="<?php echo base_url("front/doAddAppointment"); ?>">
														<input type="hidden" name="doctorId" id="doctorId" value="<?php echo $value['tblDocDataId']; ?>">
														<div class="form-group">
															<input type="date" name="appDate" id="appDate" class="form-control">
														</div>
														<div class="row">
															<div class="col-md-4 col-md-offset-4">
																<div class="form-group">
																	<input type="submit" name="appDateSub" id="appDateSub" class="btn btn-block btn-success" value="Set Appontment">
																</div>
															</div>
														</div>
														<?php
															if ($this->session->has_userdata("docMail")) {
																?>
																	<input type="hidden" name="patType" id="patType" value="Doctor">
																	<input type="hidden" name="appPatId" id="appPatId" value="<?php echo $user_info['tblDocDataId']; ?>">
																<?php
															}elseif ($this->session->has_userdata("patientMail")) {
																?>
																	<input type="hidden" name="patType" id="patType" value="Patient">
																	<input type="hidden" name="appPatId" id="appPatId" value="<?php echo $user_info['tblPatientDataId']; ?>">
																<?php
															}
														?>
													</form>
												</div>
											</div>
										</div>
									</div>
									<div id="msg-modal" class="modal fade msg-modal">
										<div class="modal-dialog">
											<div class="modal-content">
												<div class="modal-header">
													<button class="close" data-dismiss="modal">&times;</button>
													<p class="h3 text-center" style="font-weight: bold;color:#5cb85c; ">Type your message!</p>
												</div>
												<form id="message-send-form" method="POST" action="<?php echo base_url("front/doSendMessage"); ?>">
													<div class="alert alert-danger alert-dismissible hidden" role="alert" id="alert-msg">
														<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
													</div>
													<input type="hidden" name="recId" id="recId" value="<?php echo $value['tblDocDataId']; ?>">
													<input type="hidden" name="recType" id="recType" value="Doctor">
													<div class="modal-body">
														<div class="form-group">
															<textarea cols="75" rows="10" maxlength="2000" placeholder="Type your message..." name="message"></textarea>
															<i>Not more than 2000 characters...</i>
														</div>
														<div class="form-group">
															<input type="submit" name="msgSub" id="msgSub" class="btn btn-block btn-success" value="send">
														</div>
													</div>
													<?php
															if ($this->session->has_userdata("docMail")) {
																?>
																	<input type="hidden" name="sendType" id="sendType" value="Doctor">
																	<input type="hidden" name="sendId" id="sendId" value="<?php echo $user_info['tblDocDataId']; ?>">
																<?php
															}elseif ($this->session->has_userdata("patientMail")) {
																?>
																	<input type="hidden" name="sendType" id="sendType" value="Patient">
																	<input type="hidden" name="sendId" id="sendId" value="<?php echo $user_info['tblPatientDataId']; ?>">
																<?php
															}
														?>
												</form>
											</div>
										</div>
									</div>
									<!-- if wanna create a modal for each side option then make here -->
								<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="alert-modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" data-dismiss="modal">&times;</button>
				<p class="h3 text-center message" style="font-weight: bold;color: red;"></p>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<a id="linkRoute" class="btn btn-success btn-block" href="<?php echo base_url("front/login_option"); ?>">OK</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>