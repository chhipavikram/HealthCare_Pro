<div id="doc-list-banner">
	<div class="myDashContent">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="doc-list-body">
						<div id="doc-list-search-pane">
							<form class="form-inline">
								<div id="state-search" class="form-group col-md-3 col-md-offset-2">
									<select class="state-list" id="state-list" name="state-list">
										<?php
											foreach ($city as $value) {
												?>
													<option value="<?php echo $value['state_id']; ?>"><?php echo $value['state_name']; ?></option>
												<?php
											}
										?>
									</select>
								</div>
								<div id="city-search" class="form-group col-md-3">
									<select class="city-list form-control" id="city-list" name="city-list" style="width: 100%;">
										<option value="0" selected="selected">--Select City--</option>
										<!-- city listing -->
									</select>
								</div>
								<div id="speciality-search" class="form-group col-md-3">
									<select class="speciality-list" id="speciality-list" name="speciality-list">
										<?php
											foreach ($speciality as $value) {
												?>
													<option value="<?php echo $value['tblDocDegId']; ?>"><?php echo $value['tblDocDegName']; ?></option>
												<?php
											}
										?>
									</select>
								</div>
								<div id="search-btn" class="form-group col-md-1">
									<button class="btn btn-success btn-block"><i class="fa fa-search"></i></button>
								</div>
							</form>
						</div>
						<div id="doc-list-result">
							<div id="doc-list-result-content" class="container">
								hiiiiii
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>