
<div id="foot-bar">
		<div class="container">
			<p class="h5 header-second text-center"><i class="fa fa-copyright"></i>Copyrighted To VGU Bros!</p>
		</div>
	</div>