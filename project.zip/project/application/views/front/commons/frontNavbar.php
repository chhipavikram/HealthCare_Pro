<!--navigation bar start-->
	<div id="topbar">
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" aria-expanded="false" data-target="#navbar-collapse-1">
						<span class="sr-only">toggle</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<span class="brand-name">Patient-Doctor</span>
				</div>
				<div class="collapse navbar-collapse" id="navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="<?php echo base_url("front"); ?>">Home</a></li>
						<li><a href="<?php echo base_url("front#about-us-bar"); ?>">About Us</a></li>
						<li><a href="<?php echo base_url("front#article-bar"); ?>">Articles</a></li>
						<li><a href="<?php echo base_url("front#contactus-bar"); ?>">Contact Us</a></li>
						<?php
							if ($this->session->has_userdata("patientMail")) {
								?>
									<li class="dropdown">
										<a href="#" data-toggle="dropdown" id="ddn" aria-haspopup="true" aria-expanded="false" role="button" style="text-transform: uppercase;"><?php echo $user_info['tblPatientDataFName']." ".$user_info['tblPatientDataLName']; ?><span class="caret"></span></a>
										<ul class="dropdown-menu">
											<li><a href="<?php echo base_url("front/patient_dashboard"); ?>">My Dashboard</a></li>
											<li><a href="<?php echo base_url("front/doPatientLogOut"); ?>">Logout</a></li>
										</ul>
									</li>
								<?php
							}elseif ($this->session->has_userdata("docMail")) {
								?>
									<li class="dropdown">
										<a href="#" data-toggle="dropdown" id="ddn" aria-haspopup="true" aria-expanded="false" role="button" style="text-transform: uppercase;"><?php echo $user_info['tblDocDataFName']." ".$user_info['tblDocDataLName']; ?><span class="caret"></span></a>
										<ul class="dropdown-menu">
											<li><a href="<?php echo base_url("front/docDashboard"); ?>">My Dashboard</a></li>
											<li><a href="<?php echo base_url("front/doDocLogOut"); ?>">Logout</a></li>
										</ul>
									</li>
								<?php
							}else{
								?>
									<li><a href="<?php echo base_url("front/login_option"); ?>">Sign in/Sign up</a></li>
								<?php
							}
						?>						
					</ul>
				</div>
			</div>
		</nav>
	</div>