<!DOCTYPE html>
<html>
<head>
	<title>Sampple</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/front/css/bootstrap.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/front/css/font-awesome.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/front/css/selectize.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/front/css/style.css"); ?>">
	<script type="text/javascript">
		var siteUrl = "<?php echo site_url(); ?>";
	</script>
</head>
<body>