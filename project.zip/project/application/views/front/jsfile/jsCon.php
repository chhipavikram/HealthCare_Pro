<script src="<?php echo base_url("assets/front/jquery/jquery.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/front/js/bootstrap.min.js"); ?>"></script>