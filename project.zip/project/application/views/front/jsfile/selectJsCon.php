<script src="<?php echo base_url("assets/front/js/selectize.js"); ?>"></script>
