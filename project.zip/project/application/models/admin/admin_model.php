<?php
class admin_model extends CI_MODEL
{
	
	function __constructor()
	{
		parent::__constructor();
	}
	public function isAuthUser(){
		$query=$this->db->get_where("tbladmindetail",['adminMail'=>$this->input->post("admin-login-mail"),'adminPass'=>$this->input->post("admin-login-pass")]);
		return $query->num_rows()===1;
	}
	public function get_User_Data($email){
			$query=$this->db->get_where("tbladmindetail",['email=>$email']);
			$this->db->select('id','adminMail','adminPass','adminPhone');
			return $query->row_array();
	}
	public function changeAdminPass($id){
		$this->db->where('id',$id);
		return $this->db->update("tbladmindetail",["adminPass"=>$this->input->post('adminNewPass')]);
	}
	public function changeAdminProfile($id){
		$this->db->where("id",$id);
		return $this->db->update("tbladmindetail",["adminMail"=>$this->input->post("adminChangeProfileMail"),"adminPhone"=>$this->input->post("adminChangeProfileNumber")]);
	}
}
?>