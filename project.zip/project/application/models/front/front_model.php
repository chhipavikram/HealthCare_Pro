<?php
class front_model extends CI_MODEL
{
	
	function __constructor()
	{
		parent::__construct();
	}
	public function getTableData($tblname){
		$query=$this->db->get($tblname);
		return $query->result_array();
	}

	//very important in CI db
	public function getJoinTableData($tblname1,$tblname2,$condition){
		$this->db->select("*");
		$this->db->from($tblname1);
		$this->db->join($tblname2,$condition);
		$query=$this->db->get();
		return $query->result_array();
	}
	public function getTableDataConditional($tblname,$condition){
		$query=$this->db->get_where($tblname,$condition);
		return $query->row_array();
	}
	public function getTableDataConditionalSet($tblname,$condition){
		$query=$this->db->get_where($tblname,$condition);
		return $query->result_array();
	}
	public function insertTo($tblname,$data){
		return $this->db->insert($tblname,$data);
	}
	public function isAuthUser($tblname,$condition){
		$query=$this->db->get_where($tblname,$condition);
		return $query->num_rows()==1;
	}
	public function checkExist($tblname,$condition){
		$query=$this->db->get_where($tblname,$condition);
		return $query->num_rows()==1;
	}
	public function deleteData($tblname,$id,$matchcol){
		$this->db->where($matchcol,$id);
		return $this->db->delete($tblname);
	}
	public function updateRow($tblname,$data,$condition,$match){
		$this->db->set($data);
		$this->db->where($match,$condition);
		return $this->db->update($tblname);
	}
	public function getInboxDoctor($condition){
		$query=$this->db->query("select * from tblmsg where ".$condition." group by msgSendId order by msgParent");
		return $query->result_array();
	}
	public function getConvoAtDoctor(){
		$condition="(msgSendId=".$this->session->userdata("p2")." and msgRecId=".$this->session->userdata("p1")." and msgSendType='Patient' and msgRecType='Doctor') or (msgSendId=".$this->session->userdata("p1")." and msgRecId=".$this->session->userdata("p2")." and msgSendType='Doctor' and msgRecType='Patient') or (msgSendId=".$this->session->userdata("p1")." and msgRecId=".$this->session->userdata("p2")." and msgSendType='Doctor' and msgRecType='Doctor') or (msgSendId=".$this->session->userdata("p2")." and msgRecId=".$this->session->userdata("p1")." and msgSendType='Doctor' and msgRecType='Doctor')";
		$query=$this->db->query("select * from tblmsg where ".$condition." order by msgParent");
		return $query->result_array();
	}
	public function getInboxPatient($condition){
		$query=$this->db->query("select * from tblmsg where ".$condition." group by msgSendId order by msgParent");
		return $query->result_array();	
	}
	public function getConvoAtPatient(){
		$condition="(msgSendId=".$this->session->userdata("p2")." and msgRecId=".$this->session->userdata("p1")." and msgSendType='Doctor' and msgRecType='Patient') or (msgSendId=".$this->session->userdata("p1")." and msgRecId=".$this->session->userdata("p2")." and msgSendType='Patient' and msgRecType='Doctor')";
		$query=$this->db->query("select * from tblmsg where ".$condition." order by msgParent");
		return $query->result_array();	
	}
	public function updateAppointmentStatus(){
		$condition="appPatId=".$this->input->post("patId")." AND appDocId=".$this->input->post("docId")." AND appPatType='".$this->input->post("patType")."' AND appDate='".$this->input->post("appDate")."'";
		$d="appStat='".$this->input->post("appStat")."'";
		return $this->db->query("update tblappointment set ".$d." where ".$condition);
	}
	public function cancelAppointment(){
		$condition="appPatId=".$this->input->post("patId")." AND appDocId=".$this->input->post("docId")." AND appPatType='".$this->input->post("patType")."' AND appDate='".$this->input->post("appDate")."'";
		$d="appStat='".$this->input->post("appStat")."'";
		return $this->db->query("update tblappointment set ".$d." where ".$condition);
	}
	public function checkAppointment(){
		$condition="appPatId=".$this->input->post("appPatId")." AND appDocId=".$this->input->post("doctorId")." AND appPatType='".$this->input->post("patType")."' AND appDate='".$this->input->post("appDate")."' AND NOT appStat='Canceled'";
		$query=$this->db->query("select * from tblappointment where ".$condition);
		return $query->result_array()==1;
	}
}
?>
