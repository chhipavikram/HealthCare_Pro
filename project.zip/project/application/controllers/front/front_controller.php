<?php
class front_controller extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model("front/front_model");
	}
	public function index(){
		if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }
		 if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }
		$data['city']=$this->front_model->getTableData("tbl_states");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$this->load->view("front/body/homesec/homeBanner",$data);
		$this->load->view("front/body/homesec/stepBar");
		$this->load->view("front/body/homesec/articleBar");
		$this->load->view("front/body/homesec/aboutUsBar");
		$this->load->view("front/body/homesec/socialContactBar");
		$this->load->view("front/body/contactUsBar");
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/selectJsCon");
		$this->load->view("front/jsfile/eventjsCon");
		$this->load->view("front/jsfile/locSearchJsCon");
		$this->load->view("front/jsfile/docListJsCon");
		$this->load->view("front/commons/end");
	}

	public function doGetCityList(){
		$this->output->set_content_type("application/json");
		$condition=['state_id'=>$this->input->post("state_id")];
		$city=$this->front_model->getTableDataConditionalSet("tbl_cities",$condition);
		$this->output->set_output(json_encode(['city'=>$city]));
		return FALSE;
	}

	/*public function doGetDocsList(){
		$this->output->set_content_type("application/json");
		if ($this->session->has_userdata("patientMail") || $this->session->has_userdata("docMail")) {
			$docDetail=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tblclinicdet.tblClinicDocId=tbldocdata.tblDocDataId");
			$a=array();
			foreach ($docDetail as $value) {
				if ($value['tblClinicCity']==$this->input->post("citylist")) {
					$a[]=$value;
				}
			}
			if (!empty($a)) {
				$this->output->set_output(json_encode(['result'=>1,'url'=>'front/docSearchList/'.$a]));
			}else{
				$this->output->set_output(json_encode(['result'=>1,'url'=>'front/docSearchList/'."0"]));
			}
			return FALSE;	
		}else{
			$this->output->set_output(json_encode(['result'=>0,'msg'=>'Login/Register before you search for the dooctor']));
			return FALSE;
		}
	}*/

	public function docSearchList(){
			$docDetail=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tblclinicdet.tblClinicDocId=tbldocdata.tblDocDataId");
			$a=array();
			$data["testData"]=$docDetail;
			$data['testCity']=$this->input->post("citylist");
			//var_dump($this->input->post());die;
			if (!empty($this->input->post("specialitylist"))) {
				foreach ($docDetail as $value) {
					if ($value['tblClinicCity']==$this->input->post("citylist") && $value['tblDocDataSpeciality']==$this->input->post("specialitylist")) {
						$a[]=$value;
					}
				}
				if (!empty($a)) {
					$data['docData']=$a;
				}else{
					$a=" ";
					$data['docData']=$a;
				}
				$data['specSel']=$this->input->post("specialitylist");	
			}else{
				foreach ($docDetail as $value) {
					if ($value['tblClinicCity']==$this->input->post("citylist")) {
						$a[]=$value;
					}
				}
				if (!empty($a)) {
					$data['docData']=$a;
				}else{
					$a=" ";
					$data['docData']=$a;
				}
			}

		//--new end
		$data['stateSel']=$this->input->post("statelist");
		$data['citySel']=$this->input->post("citylist");
		if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }
		 if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }
		$data['state']=$this->front_model->getTableData("tbl_states");
		$data['city']=$this->front_model->getTableData("tbl_cities");
		$data['speciality']=$this->front_model->getTableData("tbldocspeciality");
		//$docDetail=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tblclinicdet.tblClinicDocId=tbldocdata.tblDocDataId");
		//$data['docData']=$a;
		//$this->front_model->getTableData("tbldocdata");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$this->load->view("front/body/searchList/docSearchList",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/selectJsCon");
		$this->load->view("front/jsfile/eventjsCon");
		///$this->load->view("front/jsfile/docListJsCon");
		$this->load->view("front/jsfile/appointmentJsCon");
		$this->load->view("front/jsfile/messageJsCon");
		$this->load->view("front/commons/end");
	}

	public function doSendMessage(){
		$this->output->set_content_type("application/json");
		$dat1=['msgSendId'=>$this->input->post("sendId"),'msgRecId'=>$this->input->post("recId"),'msgSendType'=>$this->input->post("sendType"),'msgRecType'=>$this->input->post("recType")];
		$dat2=['msgRecId'=>$this->input->post("sendId"),'msgSendId'=>$this->input->post("recId"),'msgRecType'=>$this->input->post("sendType"),'msgSendType'=>$this->input->post("recType")];
		$res2=$this->front_model->getTableDataConditionalSet("tblmsg",$dat2);
		$res1=$this->front_model->getTableDataConditionalSet("tblmsg",$dat1);
		if (empty($res1) && empty($res2)) {
			$parent=0;
			$dat=['msgSendId'=>$this->input->post("sendId"),'msgRecId'=>$this->input->post("recId"),'msgSendType'=>$this->input->post("sendType"),'msgRecType'=>$this->input->post("recType"),'msgData'=>$this->input->post("message"),'msgParent'=>$parent];
			$res=$this->front_model->insertTo("tblmsg",$dat);
			if ($res) {
				$this->output->set_output(json_encode(['result'=>2,'msg'=>'Sent Successfully!']));
			}else{
				$this->output->set_output(json_encode(['result'=>-2,'msg'=>'Sending Failed!']));
			}
		}else{
			$dat=['msgSendId'=>$this->input->post("sendId"),'msgRecId'=>$this->input->post("recId"),'msgSendType'=>$this->input->post("sendType"),'msgRecType'=>$this->input->post("recType"),'msgData'=>$this->input->post("message"),'msgParent'=>$this->input->post("msgParent")];
			$res=$this->front_model->insertTo("tblmsg",$dat);
			if ($res) {
				$this->output->set_output(json_encode(['result'=>2,'msg'=>'Sent successfully!']));
			}else{
				$this->output->set_output(json_encode(['result'=>-2,'msg'=>'Could not send!']));
			}
		}	
		return FALSE;
	}

	public function doCheckUser(){
		$this->output->set_content_type("application/json");
		if ($this->input->post("userType")==1) {
			$this->output->set_output(json_encode(['result'=>1]));
		}elseif ($this->input->post("userType")==2) {
			$this->output->set_output(json_encode(['result'=>0]));
		}elseif ($this->input->post("userType")==13) {
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'You cannot send yourself a message/Set an appointment with yourself!']));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Login/Register first to set appointment']));
		}
		return FALSE;
	}

	public function doAddAppointment(){
		$this->output->set_content_type("appointment/json");
		$result=$this->front_model->checkAppointment();
		/*$dat=['appDocId'=>$this->input->post("doctorId"),'appPatId'=>$this->input->post("appPatId"),'appDate'=>$this->input->post("appDate")];
		$result=$this->front_model->checkExist("tblappointment",$dat);*/
		if (!$result) {
				$dat=['appDocId'=>$this->input->post("doctorId"),'appPatId'=>$this->input->post("appPatId"),'appDate'=>$this->input->post("appDate"),'appPatType'=>$this->input->post("patType")];
				$res=$this->front_model->insertTo("tblappointment",$dat);
				if ($res) {
					$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Appointment Requested!']));
				}else{
					$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Could not set appointment']));
				}
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Appointment set already!']));
		}
		return FALSE;
	}

	public function login_option(){
		if ($this->session->has_userdata('patientMail') || $this->session->has_userdata("docMail")){
			redirect("front");			
		}
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar");
		$data['docSignIn']=$this->load->view("front/body/frontlogin/docSignInFront","",TRUE);
		$data['patSignIn']=$this->load->view("front/body/frontlogin/patSignInFront","",TRUE);
		$data['docSignUp']=$this->load->view("front/body/frontlogin/docSignUpFront","",TRUE);
		$data['patSignUp']=$this->load->view("front/body/frontlogin/patSignUpFront","",TRUE);
		$this->load->view("front/body/frontlogin/loginOpt",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/patientEventJsCon");
		$this->load->view("front/jsfile/docLoginJsCon");
		$this->load->view("front/commons/end");
	}

/*patient module start*/

	public function doPatientSignUp(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("patRegFName","First Name","required");
		$this->form_validation->set_rules("patRegLName","Last Name","required");
		$this->form_validation->set_rules("patRegMail","Email","required|valid_email");
		$this->form_validation->set_rules("patRegNum","Phone Number","required|is_natural");
		$this->form_validation->set_rules("patRegPass","Password","required|min_length[6]");
		$this->form_validation->set_rules("patRegConPass","Confirm Password","required|matches[patRegPass]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$con=["tblPatientDataMail"=>$this->input->post("patRegMail")];
		$res=$this->front_model->checkExist("tblpatientdata",$con);
		if (!$res) {
			$data=['tblPatientDataFName'=>$this->input->post('patRegFName'),'tblPatientDataMName'=>$this->input->post('patRegMName'),'tblPatientDataLName'=>$this->input->post('patRegLName'),'tblPatientDataMail'=>$this->input->post('patRegMail'),'tblPatientDataPNo'=>$this->input->post('patRegNum'),'tblPatientDataPass'=>$this->input->post('patRegPass')];
			$result=$this->front_model->insertTo('tblpatientdata',$data);
			if ($result) {
				$this->output->set_output(json_encode(['result'=>1,'msg'=>'You have signed up successfully!! Sign in to continue']));
			}else{
				$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Sign up unsuccessful']));
			}
		}else{
				$this->output->set_output(json_encode(['result'=>1,"msg"=>"Account exists already!! Sign in to continue"]));
		}
		return FALSE;		
	}
	public function doPatientSignIn(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("patientLoginMail","Email","required|valid_email");
		$this->form_validation->set_rules("patientLoginPass","Password","required");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
		}
		$con=["tblPatientDataMail"=>$this->input->post("patientLoginMail")];
		$res=$this->front_model->checkExist("tblpatientdata",$con);
		if ($res) {
			$condition=['tblPatientDataMail'=>$this->input->post("patientLoginMail"),'tblPatientDataPass'=>$this->input->post("patientLoginPass")];
			$result=$this->front_model->isAuthUser("tblpatientdata",$condition);
			if ($result) {
				$this->output->set_output(json_encode(['result'=>2,'url'=>base_url("front/patient_dashboard")]));
				$this->session->set_userdata(['patientMail'=>$this->input->post("patientLoginMail")]);
			}else{
				$this->output->set_output(json_encode(["result"=>-2,'msg'=>'Username/Password mismatch']));
			}
		}else{
			$this->output->set_output(json_encode(['result'=>-3,'msg'=>'Resgister yourself first!']));
		}
		
	}
	public function doPatientLogOut(){
		$this->session->sess_destroy("patientMail");
		redirect("front");
	}
	public function patient_dashboard(){
		 if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		 $this->load->view("front/commons/headFront");
		 $this->load->view("front/commons/frontNavbar",$data);
		 $data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardHome",$data,TRUE);
		 $this->load->view("front/body/patientDash/patientDashboard",$data);
		 $this->load->view("front/commons/footBar");
		 $this->load->view("front/jsfile/jsCon");
		 $this->load->view("front/jsfile/patientDashEventJsCon");
		 $this->load->view("front/commons/end");
	}

	public function patientDashboardInbox(){
		if ($this->session->has_userdata("p1")) {
			$this->session->unset_userdata("p1");	
		}
		if ($this->session->has_userdata("p2")) {
			$this->session->unset_userdata("p2");
		}		
		if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		 $dat=['msgRecId'=>$det['tblPatientDataId'],'msgRecType'=>'Patient'];
		$res=$this->front_model->getTableDataConditionalSet("tblmsg",$dat);
		if (empty($res)) {
			$data['msgInbox']="";
		}else{
			$condition="msgRecId=".$det['tblPatientDataId']." AND msgRecType='Patient'";
			$result=$this->front_model->getInboxPatient($condition);
			$data['msgInbox']=$result;
		}
		$data['docTbl']=$this->front_model->getTableData("tbldocdata");
		 $this->load->view("front/commons/headFront");
		 $this->load->view("front/commons/frontNavbar",$data);
		 $data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardInbox",$data,TRUE);
		 $this->load->view("front/body/patientDash/patientDashboard",$data);
		 $this->load->view("front/commons/footBar");
		 $this->load->view("front/jsfile/jsCon");
		 $this->load->view("front/jsfile/patientDashEventJsCon");
		 $this->load->view("front/commons/end");
	}

	public function patientDashboardMessage(){
		if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		 if (!$this->session->has_userdata("p1")) {
		 	$this->session->set_userdata(['p1'=>$this->input->post("p1")]);
		 }
		 if (!$this->session->has_userdata("p2")) {
		 	$this->session->set_userdata(['p2'=>$this->input->post("p2")]);
		 }
		$data['docTbl']=$this->front_model->getTableDataConditional("tbldocdata",['tblDocDataId'=>$this->session->userdata("p2")]);
		$res=$this->front_model->getConvoAtPatient();
		$data['message']=$res;
		$this->load->view("front/commons/headFront");
		 $this->load->view("front/commons/frontNavbar",$data);
		 $data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardMessage",$data,TRUE);
		 $this->load->view("front/body/patientDash/patientDashboard",$data);
		 $this->load->view("front/commons/footBar");
		 $this->load->view("front/jsfile/jsCon");
		 $this->load->view("front/jsfile/patientDashEventJsCon");
		 $this->load->view("front/jsfile/messageJsCon");
		 $this->load->view("front/commons/end");
	}

	public function patientDashboardAppointment(){
		 if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		 $data['docData']=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tbldocdata.tblDocDataId=tblclinicdet.tblClinicDocId");
		 $data['patData']=$this->front_model->getJoinTableData("tblpatientdata","tblappointment","tblpatientdata.tblPatientDataId=tblappointment.appPatId");
		 $this->load->view("front/commons/headFront");
		 $this->load->view("front/commons/frontNavbar",$data);
		 $data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardAppointment",$data,TRUE);
		 $this->load->view("front/body/patientDash/patientDashboard",$data);
		 $this->load->view("front/commons/footBar");
		 $this->load->view("front/jsfile/jsCon");
		 $this->load->view("front/jsfile/patientDashEventJsCon");
		 $this->load->view("front/jsfile/cancelAppointmentJsCon");
		 $this->load->view("front/commons/end");
	}
	public function doCancelAppointment(){
		$this->output->set_content_type("application/json");
		$res=$this->front_model->cancelAppointment();
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'url'=>base_url("front/patientDashboardAppointment")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'could not cancel']));
		}
		return FALSE;
	}
	public function doCancelAppointmentDoc(){
		$this->output->set_content_type("application/json");
		$res=$this->front_model->cancelAppointment();
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'url'=>base_url("front/docOwnAppointment")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'could not cancel']));
		}
		return FALSE;	
	}
	public function patientDashboardProfile(){
		 if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardProfile",$data,TRUE);
		$this->load->view("front/body/patientDash/patientDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/patientDashEventJsCon");
		$this->load->view("front/commons/end");
	}
	public function doPatientProfileUpdate(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("patientFName","First Name","required");
		$this->form_validation->set_rules("patientLName","Last Name","required");
		$this->form_validation->set_rules("patientMail","Email","required|valid_email");
		$this->form_validation->set_rules("patientPno","Phone Number","required|is_natural");
		$this->form_validation->set_rules("patientAddr","Address","required");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$data=['tblPatientDataFName'=>$this->input->post("patientFName"),'tblPatientDataMName'=>$this->input->post("patientMName"),'tblPatientDataLName'=>$this->input->post("patientLName"),'tblPatientDataMail'=>$this->input->post("patientMail"),'tblPatientDataPNo'=>$this->input->post("patientPno"),'tblPatientDataAddr'=>$this->input->post("patientAddr")];
		$id=$this->input->post("patientDataId");
		$res=$this->front_model->updateRow("tblpatientdata",$data,$id,"tblPatientDataId");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'msg'=>'Update successful','url'=>base_url("front/patientDashboardProfile")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Update unsuccessful']));
		}
		return FALSE;
	}
	public function patientDashboardSettings(){
		 if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardSettings","",TRUE);
		$this->load->view("front/body/patientDash/patientDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/commons/end");
	}
	public function patientDashboardChangePass(){
		 if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['patientDashBody']=$this->load->view("front/body/patientDash/patientDashboardChangePass",$data,TRUE);
		$this->load->view("front/body/patientDash/patientDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/patientDashEventJsCon");
		$this->load->view("front/commons/end");
	}
	public function doChangePatientPass(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("patientNPass","New Password","required|min_length[6]");
		$this->form_validation->set_rules("patientCPass","Confirm Password","required|matches[patientNPass]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$data=['tblPatientDataPass'=>$this->input->post("patientNPass")];
		$res=$this->front_model->updateRow("tblpatientdata",$data,$this->input->post("patientId"),"tblPatientDataId");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'msg'=>'password change successfully']));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'could not change password']));
		}
		return FALSE;
	}
	public function patientDeleteAccount(){
		if ($this->session->has_userdata('patientMail')) {
		 	$condition=['tblPatientDataMail'=>$this->session->userdata('patientMail')];
		 	$det=$this->front_model->getTableDataConditional('tblpatientdata',$condition);
		 }
		 $res=$this->front_model->deleteData("tblpatientdata",$det['tblPatientDataId'],"tblPatientDataId");
		 if ($res) {
		 	$this->session->sess_destroy();
		 }
		 redirect("front");
	}

	/*patient module close*/

	/*doctor module start*/

	public function doDocSignUp(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("docRegFName","First Name","required");
		$this->form_validation->set_rules("docRegLName","Last Name","required");
		$this->form_validation->set_rules("docRegMail","Email","required|valid_email");
		$this->form_validation->set_rules("docRegNum","Phone Number","required|is_natural");
		$this->form_validation->set_rules("docRegPass","Password","required|min_length[6]");
		$this->form_validation->set_rules("docRegConPass","Confirm Password","required|matches[docRegPass]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$con=["tblDocDataMail"=>$this->input->post("docRegMail")];
		$res=$this->front_model->checkExist("tbldocdata",$con);
		if (!$res) {
			$data=['tblDocDataFName'=>$this->input->post('docRegFName'),'tblDocDataMName'=>$this->input->post('docRegMName'),'tblDocDataLName'=>$this->input->post('docRegLName'),'tblDocDataMail'=>$this->input->post('docRegMail'),'tblDocDataPNo'=>$this->input->post('docRegNum'),'tblDocDataPass'=>$this->input->post('docRegPass')];
			$result=$this->front_model->insertTo('tbldocdata',$data);
			if ($result) {
				$this->output->set_output(json_encode(['result'=>1,'msg'=>'You have signed up successfully!! Sign in to continue']));
			}else{
				$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Sign up Unsuccessful']));
			}
		}else{
				$this->output->set_output(json_encode(['result'=>1,"msg"=>"Account exists already!! Sign in to continue"]));
		}
		return FALSE;		
	}

	public function doDocSignIn(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("docloginmail","Email","required|valid_email");
		$this->form_validation->set_rules("docloginpass","Password","required");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$con=["tblDocDataMail"=>$this->input->post("docloginmail")];
		$res=$this->front_model->checkExist("tbldocdata",$con);
		if ($res) {
			$condition=['tblDocDataMail'=>$this->input->post("docloginmail"),'tblDocDataPass'=>$this->input->post("docloginpass")];
			$result=$this->front_model->isAuthUser("tbldocdata",$condition);
			if ($result) {
				$this->output->set_output(json_encode(['result'=>2,'url'=>base_url("front/docDashboard")]));
				$this->session->set_userdata(['docMail'=>$this->input->post("docloginmail")]);
			}else{
				$this->output->set_output(json_encode(["result"=>-2,'msg'=>'Username/Password mismatch']));
			}
		}else{
			$this->output->set_output(json_encode(['result'=>-3,'msg'=>'Register yourself first!']));
		}
		return FALSE;
	}

	public function doDocLogOut(){
		$this->session->sess_destroy("docMail");
		redirect("front");
	}

	public function docDashboard(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$data['docClinicDet']=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tblclinicdet.tblClinicDocId=".$det['tblDocDataId']);
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardHome",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/commons/end");
	}

	public function docDashboardInbox(){
		if ($this->session->has_userdata("p1")) {
			$this->session->unset_userdata("p1");	
		}
		if ($this->session->has_userdata("p2")) {
			$this->session->unset_userdata("p2");	
		}
		if ($this->session->has_userdata("Typep2")) {
			$this->session->unset_userdata("Typep2");	
		}
		if ($this->session->has_userdata("Typep1")) {
			$this->session->unset_userdata("Typep1");	
		}
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$dat=['msgRecId'=>$det['tblDocDataId'],'msgRecType'=>'Doctor'];
		$res=$this->front_model->getTableDataConditionalSet("tblmsg",$dat);
		if (empty($res)) {
			$data['msgInbox']="";
		}else{
			$condition="msgRecId=".$det['tblDocDataId']." AND msgRecType='Doctor'";
			$result=$this->front_model->getInboxDoctor($condition);
			$data['msgInbox']=$result;
		}
		$data['docTbl']=$this->front_model->getTableData("tbldocdata");
		$data['patTbl']=$this->front_model->getTableData("tblpatientdata");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardInbox",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/commons/end");	
	}

	public function docDashboardMessage(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		 if (!$this->session->has_userdata("p1")) {
		 	$this->session->set_userdata(['p1'=>$this->input->post("p1")]);
		 }
		 if (!$this->session->has_userdata("p2")) {
		 	$this->session->set_userdata(['p2'=>$this->input->post("p2")]);
		 }
		 if (!$this->session->has_userdata("Typep2")) {
		 	$this->session->set_userdata(['Typep2'=>$this->input->post("Typep2")]);
		 }
		 if (!$this->session->has_userdata("Typep1")) {
		 	$this->session->set_userdata(['Typep1'=>$this->input->post("Typep1")]);
		 }
		 if ($this->session->userdata("Typep2")=="Doctor") {
		 	$data['docTbl']=$this->front_model->getTableDataConditional("tbldocdata",['tblDocDataId'=>$this->session->userdata("p2")]);
		 }elseif ($this->session->userdata("Typep2")=="Patient") {
		 	$data['patTbl']=$this->front_model->getTableDataConditional("tblpatientdata",['tblPatientDataId'=>$this->session->userdata("p2")]);
		 }
		$res=$this->front_model->getConvoAtDoctor();
		$data['message']=$res;
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardMessage",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/messageJsCon");
		$this->load->view("front/commons/end");
	}

	public function docDashboardAppointment(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$data['patData']=$this->front_model->getJoinTableData("tblpatientdata","tblappointment","tblpatientdata.tblPatientDataId=tblappointment.appPatId");
		$data['patDocData']=$this->front_model->getJoinTableData("tbldocdata","tblappointment","tbldocdata.tblDocDataId=tblappointment.appPatId");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardAppointment",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/appointmentUpdateJsCon");
		$this->load->view("front/commons/end");	
	}
	public function docOwnAppointment(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$data['docData']=$this->front_model->getJoinTableData("tbldocdata","tblclinicdet","tbldocdata.tblDocDataId=tblclinicdet.tblClinicDocId");
		 $data['patData']=$this->front_model->getJoinTableData("tbldocdata","tblappointment","tbldocdata.tblDocDataId=tblappointment.appPatId");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardOwnAppointment",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/cancelAppointmentJsCon");
		$this->load->view("front/commons/end");	
	}
	public function doUpdateAppointmentStatus(){
		$this->output->set_content_type("application/json");
		$res=$this->front_model->updateAppointmentStatus();
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,"url"=>base_url("front/docDashboardAppointment")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>"status not changed!"]));
		}
		return FALSE;
	}

	public function docDashboardProfile(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardProfile",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/docDashEventJsCon");
		$this->load->view("front/commons/end");
	}

	public function doDocProfileUpdate(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("docFName","First Name","required");
		$this->form_validation->set_rules("docLName","Last Name","required");
		$this->form_validation->set_rules("docMail","Email","required|valid_email");
		$this->form_validation->set_rules("docPno","Phone Number","required|is_natural");
		$this->form_validation->set_rules("docAddr","Address","required");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$data=['tblDocDataFName'=>$this->input->post("docFName"),'tblDocDataMName'=>$this->input->post("docMName"),'tblDocDataLName'=>$this->input->post("docLName"),'tblDocDataMail'=>$this->input->post("docMail"),'tblDocDataPNo'=>$this->input->post("docPno"),'tblDocDataAddr'=>$this->input->post("docAddr")];
		$id=$this->input->post("docDataId");
		$res=$this->front_model->updateRow("tbldocdata",$data,$id,"tblDocDataId");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'msg'=>'Update successful','url'=>base_url("front/docDashboardProfile")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Update unsuccessful']));
		}
		return FALSE;
	}

	public function docDashboardSettings(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardSettings","",TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/commons/end");
	}

	public function docDeleteAccount(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 }
		 $res=$this->front_model->deleteData("tbldocdata",$det['tblDocDataId'],"tblDocDataId");
		 if ($res) {
		 	$this->session->sess_destroy();
		 }
		 redirect("front");
	}

	public function docDashboardChangePass(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardChangePass","",TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/docDashEventJsCon");
		$this->load->view("front/commons/end");
	}

	public function doChangeDocPass(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("docNPass","New Password","required|min_length[6]");
		$this->form_validation->set_rules("docCPass","Confirm Password","required|matches[docNPass]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$data=['tblDocDataPass'=>$this->input->post("docNPass")];
		$res=$this->front_model->updateRow("tbldocdata",$data,$this->input->post("docId"),"tblDocDataId");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>1,'msg'=>'password change successfully']));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'could not change password']));
		}
		return FALSE;
	}

	public function docDashboardOficialInfo(){
		if ($this->session->has_userdata('docMail')) {
		 	$condition=['tblDocDataMail'=>$this->session->userdata('docMail')];
		 	$det=$this->front_model->getTableDataConditional('tbldocdata',$condition);
		 	$data['user_info']=$det;
		 }else{
		 	redirect("front");
		 }
		$data['docClinic']=$this->front_model->getTableDataConditional("tblclinicdet",['tblClinicDocId'=>$det['tblDocDataId']]);
		$data['states']=$this->front_model->getTableData("tbl_states");
		$data['qual']=$this->front_model->getTableData("tbldoctordegree");
		$data['speciality']=$this->front_model->getTableData("tbldocspeciality");
		$this->load->view("front/commons/headFront");
		$this->load->view("front/commons/frontNavbar",$data);
		$data['docDashBody']=$this->load->view("front/body/docDash/docDashboardOficialInfo",$data,TRUE);
		$this->load->view("front/body/docDash/docDashboard",$data);
		$this->load->view("front/commons/footBar");
		$this->load->view("front/jsfile/jsCon");
		$this->load->view("front/jsfile/docDashEventJsCon");
		$this->load->view("front/jsfile/selectJsCon");
		$this->load->view("front/jsfile/eventjsCon");
		$this->load->view("front/jsfile/cityJsCon");
		$this->load->view("front/commons/end");
	}

	public function doAddClinicDet(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("docClinicName","Clinic Name","required");
		$this->form_validation->set_rules("docClinicAddrA","Address","required");
		$this->form_validation->set_rules("docClinicPin","PIN code","required|is_natural|max_length[6]|min_length[6]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>1,'errors'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$addr=$this->input->post("docClinicAddrA").",".$this->input->post("docClinicAddrB").",".$this->input->post("docClinicAddrC");
		$res=$this->front_model->checkExist("tblclinicdet",['tblClinicDocId'=>$this->input->post("docId")]);
		if (!$res) {
			$dat=['tblClinicDocId'=>$this->input->post("docId"),'tblClinicAddr'=>$addr,'tblClinicState'=>$this->input->post("state-list"),'tblClinicCity'=>$this->input->post("city-list"),'tblClinicPin'=>$this->input->post("docClinicPin"),'tblClinicName'=>$this->input->post("docClinicName")];
			$result=$this->front_model->insertTo("tblclinicdet",$dat);
			if ($result) {
					$this->output->set_output(json_encode(['result'=>4,'msg'=>'Update successful']));
				}else{
					$this->output->set_output(json_encode(['result'=>-4,'msg'=>'Update unsuccessful']));
				}	
		}else{
			$dat=['tblClinicAddr'=>$addr,'tblClinicState'=>$this->input->post("state-list"),'tblClinicCity'=>$this->input->post("city-list"),'tblClinicPin'=>$this->input->post("docClinicPin"),'tblClinicName'=>$this->input->post("docClinicName")];
			$result=$this->front_model->updateRow("tblclinicdet",$dat,$this->input->post("docId"),"tblClinicDocId");
			if ($result) {
				$this->output->set_output(json_encode(['result'=>4,'msg'=>'Update successful']));
			}else{
				$this->output->set_output(json_encode(['result'=>-4,'msg'=>'Update unsuccessful']));
			}
		}
		return FALSE;
	}

	public function doAddDocQual(){
		$this->output->set_content_type("application/json");
		$docId=$this->input->post("docId");
		$docData=$this->front_model->getTableDataConditional("tbldocdata",["tblDocDataId"=>$docId]);
		if (!empty($docData['tblDocDataQual'])) {
			$qArr=explode(",", $docData['tblDocDataQual']);
			//$n=sizeof($qArr)+1;
			$qualLst=implode(",", $this->input->post("qual-list"));
			$qualification=$docData['tblDocDataQual'].",".$qualLst;
		}else{
			$qualification=implode(",", $this->input->post("qual-list"));
		}
		$dat=['tblDocDataSpeciality'=>$this->input->post("docSpeciality"),'tblDocDataQual'=>$qualification];
		$res=$this->front_model->updateRow("tbldocdata",$dat,$docId,"tblDocDataId");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>2,'qual'=>$this->input->post("qual-list"),'msg'=>"Qualification added successfully!"]));
			/*if (empty($docData['tblDocDataQual'])){
				$this->output->set_output(json_encode(['result'=>2,'qual'=>$this->input->post("qual-list"),'msg'=>"Qualification added successfully!"]));
			}else{
				$this->output->set_output(json_encode(['result'=>2,'qual'=>$this->input->post("qual-list"),'msg'=>"Qualification added successfully!"]));
			}*/
		}else{
			$this->output->set_output(json_encode(['result'=>-2,'msg'=>"Could not add the qualification!"]));
		}
		return FALSE;
	}

	public function doDeleteDocQual(){
		$this->output->set_content_type("application/json");
		$docData=$this->front_model->getTableDataConditional("tbldocdata",['tblDocDataMail'=>$this->session->userdata("docMail")]);
		$qArr=explode(",", $docData['tblDocDataQual']);
		$a=array();
		foreach ($qArr as $value) {
			if ($value!=$this->input->post("qualVal")) {
				$a[]=$value;
			}
		}
		$qualification=implode(",", $a);
		$res=$this->front_model->updateRow("tbldocdata",['tblDocDataQual'=>$qualification],$this->session->userdata("docMail"),"tblDocDataMail");
		if ($res) {
			$this->output->set_output(json_encode(['result'=>3,'msg'=>'Delete Successful','url'=>'front/docDashboardOficialInfo']));
		}else{
			$this->output->set_output(json_encode(['result'=>-2,'msg'=>"Delete Unsuccessful"]));
		}
		return FALSE;
	}

	/*doctor module close*/
}
?>