<?php
class admin_controller extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("admin/admin_model");
	}
	public function index(){
		if ($this->session->has_userdata("email")) {
			redirect("admin/dashboard");
		}
		$this->load->view("admin/login_page/head");
		$this->load->view("admin/login_page/login_panel");
		$this->load->view("admin/common/jscon");
		$this->load->view("admin/links/eventjsLink");
		$this->load->view("admin/common/end");
	}
	public function do_login(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("admin-login-mail","Email","required|valid_email");
		$this->form_validation->set_rules("admin-login-pass","Password","required|min_length[6]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'error'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$result=$this->admin_model->isAuthUser();
		if ($result) {
			$this->session->set_userdata(['email'=>$this->input->post("admin-login-mail")]);
			$this->output->set_output(json_encode(['result'=>1,'msg'=>'login successful','url'=>base_url("admin/dashboard")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'username/password mismatch']));
		}
		return FALSE;
	}
	public function do_logout(){
		$this->session->sess_destroy();
		redirect("admin");
	}
	public function dashboard(){
		if (!$this->session->has_userdata('email')) {
			redirect("admin");die;
		}
		/*$this->load->view("admin/s");*/
		$this->load->view("admin/common/headCommon");
		$this->load->view("admin/common/dashboardTopbar");
		$data["sidebar"]=$this->load->view("admin/common/dashboardSidebar","",TRUE);
		$data['mainsec']=$this->load->view("admin/common/dashboardMainSection","",TRUE);
		$this->load->view("admin/dashboard/dashboardBody",$data);
		$this->load->view("admin/common/jscon");
		$this->load->view("admin/common/end");
	}
	public function change_password(){
		if (!$this->session->has_userdata("email")) {
			redirect("admin");die;
		}
		$this->load->view("admin/common/headCommon");
		$this->load->view("admin/common/dashboardTopbar");
		$data['sidebar']=$this->load->view("admin/common/dashboardSidebar","",TRUE);
		$data['pageContent']=$this->load->view("admin/dashboard/changePassword","",TRUE);
		$data['alert']=$this->load->view("admin/dashboard/alertMessage","",TRUE);
		$data['mainsec']=$this->load->view("admin/common/dashboardMainSection",$data,TRUE);
		$this->load->view("admin/dashboard/dashboardBody",$data);
		$this->load->view("admin/common/jscon");
		$this->load->view("admin/links/eventjsLink");
		$this->load->view("admin/common/end");
	}
	public function do_changePassword(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("adminNewPass","Password","required|min_length[6]");
		$this->form_validation->set_rules("adminConPass","Confirm Password","required|matches[adminNewPass]");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,"error"=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$email=$this->session->userdata("email");
		$userdata=$this->admin_model->get_User_Data($email);
		$result=$this->admin_model->changeAdminPass($userdata['id']);
		if ($result) {
			$this->output->set_output(json_encode(['result'=>2,'msg'=>'Password updated successfully']));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,'msg'=>'Password could not be updated']));
		}
		return FALSE;
	}
	public function change_profile(){
		if (!$this->session->has_userdata("email")) {
			redirect("admin");die;
		}
		$this->load->view("admin/common/headCommon");
		$this->load->view("admin/common/dashboardTopbar");
		$data['sidebar']=$this->load->view("admin/common/dashboardSidebar","",TRUE);
		$email=$this->session->userdata("email");
		$data['user_info']=$this->admin_model->get_User_Data($email);
		$data['pageContent']=$this->load->view("admin/dashboard/changeProfile",$data,TRUE);
		$data['alert']=$this->load->view("admin/dashboard/alertMessage","",TRUE);
		$data['mainsec']=$this->load->view("admin/common/dashboardMainSection",$data,TRUE);
		$this->load->view("admin/dashboard/dashboardBody",$data);
		$this->load->view("admin/common/jscon");
		$this->load->view("admin/links/eventjsLink");
		$this->load->view("admin/common/end");
	}
	public function do_changeProfile(){
		$this->output->set_content_type("application/json");
		$this->form_validation->set_rules("adminChangeProfileMail","E-mail","required");
		$this->form_validation->set_rules("adminChangeProfileNumber","Phone No","required|exact_length[10]|numeric");
		if ($this->form_validation->run()==FALSE) {
			$this->output->set_output(json_encode(['result'=>0,'error'=>$this->form_validation->error_array()]));
			return FALSE;
		}
		$email=$this->session->userdata("email");
		$userdata=$this->admin_model->get_User_Data($email);
		$result=$this->admin_model->changeAdminProfile($userdata['id']);
		if ($result) {
			$this->output->set_output(json_encode(['result'=>1,"msg"=>"Updated successfully","url"=>base_url("admin/change_profile")]));
		}else{
			$this->output->set_output(json_encode(['result'=>-1,"msg"=>"Update Unsuccessful"]));
		}
		return FALSE;
	}
}
?>